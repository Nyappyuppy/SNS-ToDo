//
//  SearchUserTableViewCell.swift
//  MyProduct
//
//  Created by Nyappi on 2022/10/19.
//

import UIKit

protocol SearchUserTableViewCellDelegate: AnyObject{
    func didTapFollowButton(tableViewCell: UITableViewCell, button: UIButton)
}

class SearchUserTableViewCell: UITableViewCell {
    
    weak var searchUserTableViewDelegate: SearchUserTableViewCellDelegate?
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var followButton: UIButton!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func didTapFollowButton(button: UIButton){
        searchUserTableViewDelegate?.didTapFollowButton(tableViewCell: self, button: button)
    }
    
    
}
