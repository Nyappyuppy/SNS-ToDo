//
//  SearchViewController.swift
//  MyProduct
//
//  Created by Nyappi on 2022/10/19.
//

import UIKit
import NCMB
import PKHUD
import Kingfisher

class SearchUserViewController: UIViewController, UISearchBarDelegate, UITableViewDataSource, UITableViewDelegate, SearchUserTableViewCellDelegate{
    
    
    var selectedPost: NCMBObject?
    var users = [NCMBUser]()
    var followingUserId = [String]()
    var searchBar: UISearchBar!
    var posts = [NCMBObject]()
    var presentuser:NCMBUser!
    var selectedUser: NCMBUser?
    
    @IBOutlet weak var searchUserTableView: UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        guard let currentUser = NCMBUser.current() else {
                   //ログインに戻る
                   //ログアウト登録成功
                   let storyboard = UIStoryboard(name: "SignIn", bundle: Bundle.main)
                   let RootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
                   UIApplication.shared.keyWindow?.rootViewController = RootViewController
                   //ログアウト状態の保持
                   let ud = UserDefaults.standard
                   ud.set(false, forKey: "isLogin")
                   ud.synchronize()
                   return
            
               }
        
        setSearchBar()
        searchUserTableView.dataSource = self
        searchUserTableView.delegate = self
        // カスタムセルの登録
        let nib = UINib(nibName: "SearchUserTableViewCell", bundle: Bundle.main)
        searchUserTableView.register(nib, forCellReuseIdentifier: "searchCell")
        // 余計な線を消す
        searchUserTableView.tableFooterView = UIView()
        searchUserTableView.rowHeight = 60
        

        // Do any additional setup after loading the view.
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
           loadUsers(searchText: nil)
       }
    
    func setSearchBar() {
            // NavigationBarにSearchBarをセット
            if let navigationBarFrame = self.navigationController?.navigationBar.bounds {
                let searchBar: UISearchBar = UISearchBar(frame: navigationBarFrame)
                searchBar.delegate = self
                searchBar.placeholder = "検索"
                searchBar.autocapitalizationType = UITextAutocapitalizationType.none
                navigationItem.titleView = searchBar
                navigationItem.titleView?.frame = searchBar.frame
                self.searchBar = searchBar
            }
        }
    
    func searchBarShouldBeginEditing(_ searchBar: UISearchBar) -> Bool {
           searchBar.setShowsCancelButton(true, animated: true)
           return true
       }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
            loadUsers(searchText: nil)
            searchBar.showsCancelButton = false
            searchBar.resignFirstResponder()
        }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
            loadUsers(searchText: searchBar.text)
        }
   
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toSelectedUser"{
            let selectedUserViewController = segue.destination as! SelectedUserViewController
            
            let selectedIndex = searchUserTableView.indexPathForSelectedRow!
            selectedUserViewController.afterSelectedUser  = users[selectedIndex.row]
            print(selectedUser?.objectId)
//            selectedUserViewController.afterSelectedUser = selectedUser?.objectId as? String
            print(selectedUser?.objectId)

            print("--------------")

        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return users.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let searchCell = tableView.dequeueReusableCell(withIdentifier: "searchCell") as! SearchUserTableViewCell
        
//        let user = posts[indexPath.row].object(forKey: "user") as! NCMBUser
//
//        let userObjectId = user.object(forKey: "objectId") as! String
        let appId = "BAv7MRjuGKuR33Jj"
        let userImageUrl = "https://mbaas.api.nifcloud.com/2013-09-01/applications/" + appId + "/publicFiles/" + users[indexPath.row].objectId
        
        print(users[indexPath.row].objectId,"aaa")
        

        searchCell.userImageView.kf.setImage(with: URL(string: userImageUrl), placeholder: UIImage(systemName: "person"), options: nil, progressBlock: nil)
        searchCell.userImageView.layer.cornerRadius = searchCell.userImageView.bounds.width / 2.0
        searchCell.userImageView.layer.masksToBounds = true
       // searchCell.followButton.layer.borderColor = UIColor.systemGray3.cgColor
     //   searchCell.followButton.layer.borderWidth = 1
        searchCell.followButton.layer.cornerRadius = 17
        
        searchCell.followButton.backgroundColor = UIColor{_ in return #colorLiteral(red: 0.4016079903, green: 0.7575066686, blue: 0.7143911123, alpha: 1)}
        searchCell.followButton.tintColor = UIColor.white
        
        
        
        searchCell.userNameLabel.text = users[indexPath.row].object(forKey: "userName") as? String
        
        searchCell.tag = indexPath.row
        searchCell.searchUserTableViewDelegate = self
        print(followingUserId, "kokokokookoko")
        let query = NCMBQuery(className: "follow")
        query?.whereKey("user", equalTo: NCMBUser.current())
        query?.whereKey("followingUser", equalTo: selectedUser)
        query?.findObjectsInBackground({(result, error) in
            if error != nil{
                print(error)
            }else{
                if self.followingUserId.contains(self.users[indexPath.row].objectId) == true {
                    searchCell.followButton.isHidden = true
                } else {
                    searchCell.followButton.isHidden = false
                }
            }
            
        })
        
      return searchCell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        //ほんとは、selectedUserのPost情報を引っ張りたいが、SearchUserにはPostの情報はない。
        selectedUser = users[indexPath.row]
        print(selectedUser)
       print("わああああああ")
        
        self.performSegue(withIdentifier: "toSelectedUser", sender: nil)
        tableView.deselectRow(at: indexPath, animated: true)
      
       
        
    }
    
    
    
    func didTapFollowButton(tableViewCell: UITableViewCell, button: UIButton) {
        let displayName = users[tableViewCell.tag].object(forKey: "userName") as? String
        let message = displayName! + "をフォローしますか？"
        let alert = UIAlertController(title: "フォロー", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
            self.follow(selectedUser: self.users[tableViewCell.tag])
        }
        let cancelAction = UIAlertAction(title: "キャンセル", style: .default) { (action) in
            alert.dismiss(animated: true, completion: nil)
        }
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
    }
    
   
    func follow(selectedUser: NCMBUser) {
        let object = NCMBObject(className: "follow")
        if let currentUser = NCMBUser.current() {
            object?.setObject(currentUser, forKey: "user")
            object?.setObject(selectedUser, forKey: "followingUser")
            object?.setObject("true", forKey: "following")
            object?.saveInBackground({  (error) in
                if error != nil{
                    HUD.show(.labeledError(title: error!.localizedDescription, subtitle: nil))
                }else{
                    self.loadUsers(searchText: nil)
                    
                }
            })
        }else{
            // currentUserが空(nil)だったらログイン画面へ
                       let storyboard = UIStoryboard(name: "SignIn", bundle: Bundle.main)
                       let rootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
                       UIApplication.shared.windows.first { $0.isKeyWindow }?.rootViewController = rootViewController

                       // ログイン状態の保持
                       let ud = UserDefaults.standard
                       ud.set(false, forKey: "isLogin")
                       ud.synchronize()
                   }
            
        }
        
    func loadUsers(searchText: String?) {
            let query = NCMBUser.query()
            // 自分を除外
            query?.whereKey("objectId", notEqualTo: NCMBUser.current().objectId)
            // 退会済みアカウントを除外
            query?.whereKey("active", notEqualTo: false)
            // 検索ワードがある場合
            if let text = searchText {
                print(text)
                query?.whereKey("userName", equalTo: text)
//                query?.whereKey("text",equalTo: text)
                }
        
        query?.limit = 50
                query?.order(byDescending: "createDate")
                query?.findObjectsInBackground({ (result, error) in
                    if error != nil {
                        HUD.show(.labeledError(title: error!.localizedDescription, subtitle: nil))
                    } else {
                        // 取得した新着50件のユーザーを格納
                        self.users = result as! [NCMBUser]
                        self.loadFollowingUserIds()
                    }
                })
        
        }
    
    func loadFollowingUserIds() {
            let query = NCMBQuery(className: "follow")
            query?.includeKey("followingUser")
            query?.whereKey("user", equalTo: NCMBUser.current())

            query?.findObjectsInBackground({ (result, error) in
                if error != nil {
                    HUD.show(.labeledError(title: error!.localizedDescription, subtitle: nil))
                } else {
                    self.followingUserId = [String]()
                    for following in result as! [NCMBObject] {
                        let user = following.object(forKey: "followingUser") as! NCMBUser
                        self.followingUserId.append(user.objectId)
                    }
                    self.searchUserTableView.reloadData()
                }
            })
        }
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
