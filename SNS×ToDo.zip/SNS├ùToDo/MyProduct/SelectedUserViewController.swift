//
//  SelectedUserViewController.swift
//  MyProduct
//
//  Created by Nyappi on 2022/10/21.
//

import UIKit
import NCMB
import PKHUD
import Kingfisher
import SwiftUI

class SelectedUserViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, SelectedUserTableViewCellDelegate{
    
    
   
    
    
    var selectedPost: NCMBObject?
    var posts = [NCMBObject]()
    var followings = [NCMBUser]()
    var followingUserId = [String]()
    var users = [NCMBUser]()
    var afterSelectedUser: NCMBUser!
    var selectedUser: NCMBUser!
    var blockUserIdArray = [String]()
   
    var followingInfo: NCMBObject?
    var followButtonTap: Bool = false
    var addfollow: Bool = false
    
    var ud = UserDefaults.standard
    
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var introductionTextView: UITextView!
    @IBOutlet weak var followCountLabel: UILabel!
    @IBOutlet weak var followerCountLabel: UILabel!
    @IBOutlet weak var followButton: UIButton!
    @IBOutlet weak var selectedUserTableView: UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        //プロフィール画像の角を丸くする
        userImageView.layer.cornerRadius = userImageView.bounds.width / 2
        
        guard let currentUser = NCMBUser.current() else {
                   //ログインに戻る
                   //ログアウト登録成功
                   let storyboard = UIStoryboard(name: "SignIn", bundle: Bundle.main)
                   let RootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
                   UIApplication.shared.keyWindow?.rootViewController = RootViewController
                   //ログアウト状態の保持
                   let ud = UserDefaults.standard
                   ud.set(false, forKey: "isLogin")
                   ud.synchronize()
                   return
            
               }
        
        let number = ud.integer(forKey: "likeCount")
        
        
        selectedUserTableView.dataSource = self
        selectedUserTableView.delegate = self
        selectedUserTableView.rowHeight = 400
        
        followButton.layer.cornerRadius = 17
        followButton.backgroundColor = UIColor{_ in return #colorLiteral(red: 0.4016079903, green: 0.7575066686, blue: 0.7143911123, alpha: 1)}
        followButton.tintColor = UIColor.white
        
        let nib = UINib(nibName: "SelectedUserTableViewCell", bundle: Bundle.main)
        selectedUserTableView.register(nib, forCellReuseIdentifier:"SelectedUserCell")
        selectedUserTableView.tableFooterView = UIView()

        setRefreshControl()
        loadFollowingInfo()
        checkFollowing()
     //   checkFollowButon()
            // self.follow(selectedUser: afterSelectedUser)
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        //選択したセルのユーザーのuserNameとintoroductionとuserImageを入れる
//        if let user = afterSelectedUser{
//            print(selectedUser)
//            print("ぽんぽんぽんぽんぽんぽん")
//                userNameLabel.text = user.object(forKey: "userName") as? String
//                introductionTextView.text = user.object(forKey: "introduction") as? String
//                //navigationBarのタイトルにuserIdを反映
//                //self.navigationItem.title = user.userName
//
//                //NCMBFileからuserIdが結合しているimagefileをゲットする
//                let file = NCMBFile.file(withName: (user.objectId)!, data: nil) as! NCMBFile
//                file.getDataInBackground{ (data, error) in
//                    if error != nil{
//                        print(error.debugDescription)
//                        return
//                    }
//                //取得したimageを反映
//                    if let image = UIImage(data: data!) {
//                        self.userImageView.image = image
//                    }
//                }
//            }
        
        userNameLabel.text = afterSelectedUser?.object(forKey: "userName") as? String
        introductionTextView.text = afterSelectedUser?.object(forKey: "introduction") as? String
        
        print(afterSelectedUser)
        print("ぽんぽんぽん")
        
        let file = NCMBFile.file(withName: (afterSelectedUser.objectId)!, data: nil) as! NCMBFile
        file.getDataInBackground{ (data, error) in
            if error != nil{
                print(error.debugDescription)
                return
            }
            if let image = UIImage(data: data!) {
                self.userImageView.image = image
            }
        }
       
        getBlockUser()
        checkFollowing()
   //     checkFollowButon()
        loadTimeline()
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toComment" {
            let commentViewController = segue.destination as! CommentViewController
            print(selectedPost?.objectId)
            commentViewController.postId = selectedPost?.objectId as! String
        }
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let selectedUserCell = tableView.dequeueReusableCell(withIdentifier: "SelectedUserCell") as! SelectedUserTableViewCell

        selectedUserCell.delegate = self
        selectedUserCell.tag = indexPath.row
        let user = posts[indexPath.row].object(forKey: "user") as! NCMBUser
//        selectedUser = users[indexPath.row]
       

        
        if user.object(forKey: "userName") as! String != "" {
            selectedUserCell.userNameLabel.text = user.object(forKey: "userName") as! String
        }else{
            selectedUserCell.userNameLabel.text = "表示名なし"
        }
        let userObjectId = user.object(forKey: "objectId") as! String
        let appId = "BAv7MRjuGKuR33Jj"
        let userImageUrl = "https://mbaas.api.nifcloud.com/2013-09-01/applications/" + appId + "/publicFiles/" + userObjectId

        selectedUserCell.userImageView.kf.setImage(with: URL(string: userImageUrl), placeholder: UIImage(systemName: "person"), options: nil, progressBlock: nil)

        selectedUserCell.declareTextView.text = posts[indexPath.row].object(forKey: "text") as! String
        
        selectedUserCell.favoriteButton.tintColor = UIColor{_ in return #colorLiteral(red: 1, green: 0.6676921248, blue: 0.004999437369, alpha: 1)}
        selectedUserCell.commentButton.tintColor = UIColor{_ in return #colorLiteral(red: 1, green: 0.6676921248, blue: 0.004999437369, alpha: 1)}
        if posts[indexPath.row].object(forKey: "tweet") as? String == "Declare" || posts[indexPath.row].object(forKey: "tweet") as? [String] == []{
            print("SEN")
            selectedUserCell.timeLimitLabel.text = posts[indexPath.row].object(forKey: "date") as? String
        }else{
            print("BOYA")
            selectedUserCell.timeLimitLabel.isHidden = true
        }
        let likeUsers = posts[indexPath.row].object(forKey: "likeUser") as? [String] ?? []
        if likeUsers.contains(NCMBUser.current()?.objectId as! String) == false {
                    selectedUserCell.favoriteButton.setImage(UIImage(systemName: "heart"),for: .normal)
                }else{
                    selectedUserCell.favoriteButton.setImage(UIImage(systemName: "heart.fill"),for: .normal)
                }
        selectedUserCell.favoriteCountLabel.text = "\(likeUsers.count)"
        
        

        let df = DateFormatter()
        df.dateFormat = "yyyy/MM/dd HH:mm"
        let date = posts[indexPath.row].createDate as! Date
        selectedUserCell.timestampLabel.text = df.string(from: date)
        return selectedUserCell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        selectedPost = posts[indexPath.row]
        tableView.deselectRow(at: indexPath, animated: true)
        
       
    }
    
    func didTapFavoriteButton(targetcell tableViewCell: UITableViewCell, targetButton button: UIButton) {
        guard let currentUser = NCMBUser.current() else{
            let storyboard = UIStoryboard(name: "SignIn", bundle: Bundle.main)
            let rootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
            UIApplication.shared.windows.first{ $0.isKeyWindow }?.rootViewController = rootViewController
            
            let ud = UserDefaults.standard
            ud.set(true, forKey: "isLogin")
            ud.synchronize()
            return
            
        }
        let favoriteUsers = posts[tableViewCell.tag].object(forKey: "likeUser") as? [String]
        HUD.show(.progress, onView: self.view)
        if favoriteUsers?.contains((NCMBUser.current()?.objectId)!) == false || favoriteUsers == nil {
                   //ボタンを押す前にいいねしてなかったら
                   posts[tableViewCell.tag].addUniqueObject(currentUser.objectId, forKey: "likeUser")
                   posts[tableViewCell.tag].saveEventually { error in
                       HUD.hide(animated: true)
                       if error != nil{
                           print(error)
                       }else{
                           self.loadTimeline()
                       }
                   }
               } else {
                   //ボタンを押す前にいいねしていたら
                  posts[tableViewCell.tag].removeObjects(in: [NCMBUser.current().objectId], forKey: "likeUser")
                  posts[tableViewCell.tag].saveEventually { error in
                       HUD.hide(animated: true)
                       if error != nil{
                           print(error)
                       }else{
                           self.loadTimeline()
                       }
                   }
               }
       
//            let query = NCMBQuery(className: "Declare")
//            query?.getObjectInBackground(withId: posts[tableViewCell.tag].objectId, block: { (declare,error) in
//                declare?.addUniqueObject(currentUser.objectId, forKey: "likeUser")
//                declare?.saveEventually({ (error) in
//                    HUD.hide(animated: true)
//                    if error != nil{
//                        print(error)
//                    } else {
//                        self.loadTimeline()
//                    }
//                })
//            })
//        
    }
    
    func didTapCommentButton(targetcell tableViewCell: UITableViewCell, targetButton button: UIButton) {
        selectedPost = posts[tableViewCell.tag]
        self.performSegue(withIdentifier: "toComment", sender: nil)
        
        
        guard let currentUser = NCMBUser.current() else{
            let storyboard = UIStoryboard(name: "SignIn", bundle: Bundle.main)
            let rootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
            UIApplication.shared.windows.first{ $0.isKeyWindow }?.rootViewController = rootViewController

            let ud = UserDefaults.standard
            ud.set(true, forKey: "isLogin")
            ud.synchronize()
            return
//
        }
//
//        let commentUsers = posts[tableViewCell.tag].object(forKey: "commentUser") as? [String]
//        HUD.show(.progress, onView: self.view)
////
////
//            let query = NCMBQuery(className: "Declare")
//            query?.getObjectInBackground(withId: posts[tableViewCell.tag].objectId, block: { (declare,error) in
//                declare?.addUniqueObject(currentUser.objectId, forKey: "commentUser")
//                declare?.saveEventually({ (error) in
//                    if error != nil{
//                        print(error)
//                    } else {
//                        //成功した時に消す
//                        HUD.hide(animated: true)
//                        print("roiroiroi")
//                    }
//                })
//            })
    }
    
    func didTapMenuButton(targetCell tableViewCell: UITableViewCell, targetButton button: UIButton) {
        if selectedUser == NCMBUser.current(){
            let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
            let cancelAction = UIAlertAction(title: "キャンセル", style: .cancel){ (action) in
                alertController.dismiss(animated: true, completion: nil)
                
            }
            let deleteAction = UIAlertAction(title: "削除する", style: .destructive){ (action) in
                HUD.show(.progress, onView: self.view)
                let query = NCMBQuery(className: "Declare")
                query?.getObjectInBackground(withId: self.posts[tableViewCell.tag].objectId, block: {(post, error) in
                    if error != nil{
                        print(error)
                    }else{
                        // 取得した投稿オブジェクトを削除
                        post?.deleteInBackground({ (error) in
                            if error != nil{
                                print(error)
                            }else{
                                //再読み込み
                                self.loadTimeline()
                                //読み込み(HUD)を直ちに消去する
                                HUD.hide(animated: true)
                            }
                        })
                    }
                })
            }
            alertController.addAction(deleteAction)
            alertController.addAction(cancelAction)
            
            self.present(alertController, animated: true, completion: nil)
        }else{
            let alertController = UIAlertController(title: "選択してください", message: nil, preferredStyle: .actionSheet)
            let cancelAction = UIAlertAction(title: "キャンセル", style: .cancel){ (action) in
                alertController.dismiss(animated: true, completion: nil)
                
            }
            let reportAction = UIAlertAction(title: "報告する", style: .destructive){ (action) in
                let object = NCMBObject(className: "Report")
                object?.setObject(self.posts[tableViewCell.tag].objectId, forKey: "reportPostId")
                object?.setObject(NCMBUser.current().objectId, forKey: "userId")
                object?.saveInBackground({ (error) in
                    if error != nil{
                        //もし保存する際にエラーがあったらその地域の言葉でエラーの内容を表示させます。
                        HUD.flash(.labeledError(title: error?.localizedDescription, subtitle: nil), delay: 1)
                    }else{
                        HUD.flash(.labeledError(title: "この投稿を報告しました。", subtitle: "ご協力ありがとうございました。"), delay: 1)
                        
                    }
                })
            }
            //ブロック機能
            let blockAction = UIAlertAction(title: "ブロックする", style: .default) {(action) in
                HUD.show(.progress, onView: self.view)
                //NCMBのBlockクラスにオブジェクトを追加
                let object = NCMBObject(className: "Block")
                //"blockUserId"をキーとしてブロックされる側（投稿者）のオブジェクトIDを格納
                let user = self.posts[tableViewCell.tag].object(forKey: "user") as! NCMBUser
                object?.setObject(user.objectId, forKey: "blockUserId")
                //"user"をキーとしてブロックする側（現在ログインしているユーザー）をNCMBUser型として格納
                object?.setObject(NCMBUser.current(), forKey: "user")
                //NCMB上にオブジェクトを保存
                object?.saveInBackground({ (error) in
                    if error != nil{
                        HUD.show(.progress, onView: self.view)
                    }else{
                        HUD.hide(animated: true)
                        self.getBlockUser()
                    }
                })

            }
            alertController.addAction(reportAction)
            alertController.addAction(blockAction)
            alertController.addAction(cancelAction)
            
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    func setRefreshControl() {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(reloadTimeline(refreshControl:)), for: .valueChanged)
        selectedUserTableView.addSubview(refreshControl)
    }
    @objc func reloadTimeline(refreshControl: UIRefreshControl){
        refreshControl.beginRefreshing()
        self.loadTimeline()
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            refreshControl.endRefreshing()
        }
    }
    
    
//    func checkFollowButon(){
//        let query = NCMBQuery(className: "follow")
//        query?.whereKey("user", equalTo: NCMBUser.current())
//        query?.whereKey("followingUser", equalTo: selectedUser)
//        query?.findObjectsInBackground({(result, error) in
//            if error != nil{
//                print(error)
//            }else{
//                if query?.whereKey("following", equalTo: "false") != nil || result as! [NCMBObject] == [NCMBObject()]{
//                    self.followButton.setTitle("フォロー", for: .normal)
//                    self.followButtonTap = true
//                    print("唐揚げ")
//                }else{
//
//                    self.followButton.setTitle("フォロー解除", for: .normal)
//                    self.followButtonTap = false
//                    print("魚")
//                }
//            }
//
//        })
//
//    }
    
    
   // @IBAction func follow() {
        
//        if let info = followingInfo {
//            info.deleteInBackground({ (error) in
//                if error != nil{
//                    DispatchQueue.main.asyncAfter(deadline: .now() + 2){
//                            HUD.flash(.error, delay: 1.0)
//                        }
//                    DispatchQueue.main.async {
//                        self.followButton.setTitle("フォロー解除", for: .normal)
//                        self.followButton.setTitleColor(UIColor.blue, for: .normal)
//                    }
//                }else{
//                    DispatchQueue.main.async {
//                        self.followButton.setTitle("フォローする", for: .normal)
//                        self.followButton.setTitleColor(UIColor.blue, for: .normal)
//                            }
//                        }
//                    })
//        }else{
//            let displayName = afterSelectedUser.object(forKey: "userName") as? String
//            let message = displayName! + "をフォローしますか？"
//            let alert = UIAlertController(title: "フォロー", message: message, preferredStyle: .alert)
//            let okAction = UIAlertAction(title: "OK", style: .default){ (action) in
////             self.follow(selectedUser: self.afterSelectedUser)
//                if self.followButtonTap == false{
//
//                    DispatchQueue.main.async {
//                    self.followButton.setTitle("フォロー解除", for: .normal)
//                    self.followButtonTap = true
//                    }
//                    self.follow(selectedUser: self.afterSelectedUser)
////                    self.unfollow(selectedUser: self.afterSelectedUser)
//
//                }else{
//                    DispatchQueue.main.async {
//                    self.followButton.setTitle("フォロー", for: .normal)
//                    self.followButtonTap = false
//                    }
////                    self.follow(selectedUser: self.afterSelectedUser)
//                    self.unfollow(selectedUser: self.afterSelectedUser)
//                }
//
//            }
//            let cancelAction = UIAlertAction(title: "キャンセル", style: .default) { (action) in
//                alert.dismiss(animated: true, completion: nil)
//
//            }
//            alert.addAction(okAction)
//            alert.addAction(cancelAction)
//            self.present(alert, animated: true, completion: nil)
//
////            alert.popoverPresentationController?.sourceRect = CGRect(x: screenSize.size.width/2, y:
        //}
    //    loadFollowingUserIds()
       // follow(selectedUser: afterSelectedUser)
   // }
    
//    func follow(selectedUser: NCMBUser) {
//        let object = NCMBObject(className: "follow")
//        if let currentUser = NCMBUser.current() {
//            let query = NCMBQuery(className: "follow")
//            query?.whereKey("user", equalTo: NCMBUser.current())
//            query?.whereKey("followingUser", equalTo: selectedUser)
//            query?.findObjectsInBackground({(result, error) in
//                if error != nil{
//                    print("fert")
//                    print(error)
//                }else{
//                    if result as! [NCMBObject] == [NCMBObject](){
//                        print("rrrroooo")
//                        DispatchQueue.main.async {
//                            self.followButton.setTitle("フォロー", for: .normal)
//                           // self.followButtonTap = false
//                        }
////                            self.follow(selectedUser: self.afterSelectedUser)
//                            object?.setObject(currentUser, forKey: "user")
//                            object?.setObject(selectedUser, forKey: "followingUser")
//                            object?.setObject(true, forKey: "following")
//                            object?.saveInBackground({ (error) in
//                                if error != nil{
//                                    HUD.show(.labeledError(title: error!.localizedDescription, subtitle: nil))
//                                }else{
//                                    print("true")
//
//                                    //self.ud.set("true",forKey: selectedUser.objectId)
//                                }
//                            })
//                        self.loadFollowingInfo()
//                        }else{
//                            print("ttttoooo")
//                        DispatchQueue.main.async {
//                            self.followButton.setTitle("フォロー解除", for: .normal)
//                           // self.followButtonTap = true
//                        }
//                            self.unfollow(selectedUser: self.afterSelectedUser)
//                    }
//                    self.loadFollowingInfo()
//                }
//            })
//        }else{
//            // currentUserが空(nil)だったらログイン画面へ
//                       let storyboard = UIStoryboard(name: "SignIn", bundle: Bundle.main)
//                       let rootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
//                       UIApplication.shared.windows.first { $0.isKeyWindow }?.rootViewController = rootViewController
//
//                       // ログイン状態の保持
//                       let ud = UserDefaults.standard
//                       ud.set(false, forKey: "isLogin")
//                       ud.synchronize()
//                   }
//
//        }
    
//    func unfollow(selectedUser: NCMBUser) {
//        let unfollowQuery = NCMBQuery(className: "follow")
//        if let currentUser = NCMBUser.current() {
//
//           // posts[tableViewCell.tag].removeObjects(in: [NCMBUser.current().objectId], forKey: "likeUser")
//
//            unfollowQuery?.whereKey("user", equalTo: currentUser)
//            unfollowQuery?.whereKey("followingUser", equalTo: selectedUser)
//            unfollowQuery?.whereKey("following", equalTo: "true")
//            unfollowQuery?.findObjectsInBackground({(result,error) in
//                if error != nil{
//                    print(error)
//                }else{
//                    print(selectedUser.objectId,"ppppp")
//                    DispatchQueue.main.async {
//                        self.followButton.setTitle("フォロー解除", for: .normal)
//                      //  self.followButtonTap = false
//
//                    }
//
//                    let object = NCMBObject(className: "follow")
//                    object?.setObject("false", forKey: "following")
//                    object?.saveInBackground({ (error) in
//                        if error != nil{
//                            HUD.show(.labeledError(title: error!.localizedDescription, subtitle: nil))
//                        }else{
//                            print("true")
//
//                            //self.ud.set("true",forKey: selectedUser.objectId)
//                        }
//                    })
//                self.loadFollowingInfo()
//
//
//
////                    let deleteFollow = result as! [NCMBObject]
////                    let followObject = deleteFollow[0]
////
////                    //削除実行
////                    followObject.deleteInBackground { (error) in
////                            if error != nil {
////                                print(error)
////                            } else {
////                                print("Delete succeed")
////                            }
////                        }
////
////
//
//                }
//            })
//
//        }else{
//            // currentUserが空(nil)だったらログイン画面へ
//                       let storyboard = UIStoryboard(name: "SignIn", bundle: Bundle.main)
//                       let rootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
//                       UIApplication.shared.windows.first { $0.isKeyWindow }?.rootViewController = rootViewController
//
//                       // ログイン状態の保持
//                       let ud = UserDefaults.standard
//                       ud.set(false, forKey: "isLogin")
//                       ud.synchronize()
//                   }
//           // loadFollowingUserIds()
//        }
    
    func checkFollowing() {
        //最初にボタンのラベルをどうするか
        let checkObject = NCMBObject(className: "follow")
        let aaa = NCMBObject()
        
        let query = NCMBQuery(className: "follow")
        query?.whereKey("user", equalTo: NCMBUser.current())
        query?.whereKey("followingUser", equalTo: afterSelectedUser)
        query?.findObjectsInBackground({(result, error) in
            if result?.count == 0{
                
            }else{
                let bbb = result as! [NCMBObject]
                if bbb[0].object(forKey: "following") as? String == "true" {
                    self.followButton.setTitle("フォロー解除", for: .normal)
                }
                
            }
                                         
        })
        
       
    }
    
    @IBAction func changeFollowing(){
        let query = NCMBQuery(className: "follow")
        //現在のユーザー
        query?.whereKey("user", equalTo: NCMBUser.current())
        //選択した投稿主
        query?.whereKey("followingUser", equalTo: afterSelectedUser)
        query?.findObjectsInBackground({(result, error) in
//            print("😏")
//            print(result)
//            print("😏")
            if result?.count == 0 {
                
                print("😏")
                //見つからなかったら、新しい情報を保存する（フォローする）かどうか確認する
                //フォローの手順
                let object = NCMBObject(className: "follow")
                object?.setObject(NCMBUser.current(), forKey: "user")
                object?.setObject(self.afterSelectedUser, forKey: "followingUser")
                object?.setObject("true", forKey: "following")
                object?.saveInBackground({ (error) in
                    if error != nil{
                        HUD.show(.labeledError(title: error!.localizedDescription, subtitle: nil))
                    }else{
                        //もし保存に成功したら、ボタンをフォロー解除にする
                        self.followButton.setTitle("フォロー解除", for: .normal)
                        print("follow true")
                        
                        //self.ud.set("true",forKey: selectedUser.objectId)
                    }
                })
                self.loadFollowingInfo()
                
            }else{
                //見つかった場合、フォロー/アンフォローで場合分け
                let aaa = result as! [NCMBObject]
               // let object = NCMBObject(className: "follow")
                //もしfollowingクラスがtrueなら（フォロー状態なら）
                if aaa[0].object(forKey: "following") as? String == "true" {
                    print("🌰")
                    //アンフォローにするアラートを出す
                    let displayName = self.afterSelectedUser.object(forKey: "userName") as? String
                    let unfollowMessage = displayName! + "をフォロー解除しますか？"
                    let unfollowAlert = UIAlertController(title: "フォロー解除", message: unfollowMessage, preferredStyle: .alert)
                    let okAction = UIAlertAction(title: "OK", style: .default){ (action) in
                        DispatchQueue.main.async {
                        self.followButton.setTitle("フォロー", for: .normal)
                        self.followButtonTap = false
                        }
                    }
                    let cancelAction = UIAlertAction(title: "キャンセル", style: .default) { (action) in
                        unfollowAlert.dismiss(animated: true, completion: nil)
                    }
                    
                    unfollowAlert.addAction(okAction)
                    unfollowAlert.addAction(cancelAction)
                    self.present(unfollowAlert, animated: true, completion: nil)
                    
//                    let object = NCMBObject(className: "follow")
                    //アンフォローの手順
                    aaa[0].setObject(NCMBUser.current(), forKey: "user")
                    aaa[0].setObject(self.afterSelectedUser, forKey: "followingUser")
                    aaa[0].setObject("false", forKey: "following")
                    aaa[0].saveInBackground({ (error) in
                        if error != nil{
                            HUD.show(.labeledError(title: error!.localizedDescription, subtitle: nil))
                        }else{
                            //もし保存に成功したら、ボタンをフォローにする
                            self.followButton.setTitle("フォロー", for: .normal)
                            print("unfollow true")
                            
                            //self.ud.set("true",forKey: selectedUser.objectId)
                        }
                    })
                    self.loadFollowingInfo()
                    
                    
                }else{
                    print("🍎")
                    //フォローにする
                    let displayName = self.afterSelectedUser.object(forKey: "userName") as? String
                    let followMessage = displayName! + "をフォローしますか？"
                    let followAlert = UIAlertController(title: "フォロー", message: followMessage, preferredStyle: .alert)
                    let okAction = UIAlertAction(title: "OK", style: .default){ (action) in
                        DispatchQueue.main.async {
                        self.followButton.setTitle("フォロー解除", for: .normal)
                        self.followButtonTap = true
                        }
                    }
                    let cancelAction = UIAlertAction(title: "キャンセル", style: .default) { (action) in
                        followAlert.dismiss(animated: true, completion: nil)
                    }
                    
                    followAlert.addAction(okAction)
                    followAlert.addAction(cancelAction)
                    self.present(followAlert, animated: true, completion: nil)
                    
//                    let object = NCMBObject(className: "follow")
                    //フォローの手順
                    aaa[0].setObject(NCMBUser.current(), forKey: "user")
                    aaa[0].setObject(self.afterSelectedUser, forKey: "followingUser")
                    aaa[0].setObject("true", forKey: "following")
                    aaa[0].saveInBackground({ (error) in
                        if error != nil{
                            HUD.show(.labeledError(title: error!.localizedDescription, subtitle: nil))
                        }else{
                            //もし保存に成功したら、ボタンをフォロー解除にする
                            self.followButton.setTitle("フォロー解除", for: .normal)
                            print("follow true")
                            
                            //self.ud.set("true",forKey: selectedUser.objectId)
                        }
                    })
                    self.loadFollowingInfo()
                   
                    
                }
            }
                    
        })
    }
//
//    func follow(selectedUser: NCMBUser){
//        let object = NCMBObject(className: "follow")
//        //フォローの手順
//        object?.setObject(NCMBUser.current(), forKey: "user")
//        object?.setObject(self.afterSelectedUser, forKey: "followingUser")
//        object?.setObject("true", forKey: "following")
//        object?.saveInBackground({ (error) in
//            if error != nil{
//                HUD.show(.labeledError(title: error!.localizedDescription, subtitle: nil))
//            }else{
//                //もし保存に成功したら、ボタンをフォロー解除にする
//                self.followButton.setTitle("フォロー解除", for: .normal)
//                print("follow true")
//
//                //self.ud.set("true",forKey: selectedUser.objectId)
//            }
//        })
//        self.loadFollowingInfo()
//    }
    
//    func unfollow(selectedUser: NCMBUser){
//        let object = NCMBObject(className: "follow")
//        //アンフォローの手順
//        object?.setObject(NCMBUser.current(), forKey: "user")
//        object?.setObject(self.afterSelectedUser, forKey: "followingUser")
//        object?.setObject("false", forKey: "following")
//        object?.saveInBackground({ (error) in
//            if error != nil{
//                HUD.show(.labeledError(title: error!.localizedDescription, subtitle: nil))
//            }else{
//                //もし保存に成功したら、ボタンをフォローにする
//                self.followButton.setTitle("フォロー", for: .normal)
//                print("unfollow true")
//
//                //self.ud.set("true",forKey: selectedUser.objectId)
//            }
//        })
//        self.loadFollowingInfo()
//    }
    
    
    
    func loadFollowingInfo() {
      
        //フォロー
        let followingQuery = NCMBQuery(className: "follow")
        followingQuery?.includeKey("user")
        followingQuery?.whereKey("user", equalTo: afterSelectedUser)
        followingQuery?.whereKey("following", equalTo: "true")
        followingQuery?.countObjectsInBackground({ (count, error) in
            if error != nil{
                print(error)
//                KRProgressHUD.showError(withMessage: error!.localizedDescription)
            }else{
                DispatchQueue.main.async {
                    if self.followButtonTap == false{
                        self.followCountLabel.text = String(count)
                    }
                    
                }
            }
        })
        
        //フォロワー
        let followerQuery = NCMBQuery(className: "follow")
        followerQuery?.includeKey("followingUser")
        followerQuery?.whereKey("followingUser", equalTo: afterSelectedUser)
        followerQuery?.whereKey("following", equalTo: "true")
        followerQuery?.countObjectsInBackground({ (count, error) in
            if error != nil{
                print(error)
//                KRProgressHUD.showError(withMessage: error!.localizedDescription)
            }else{
                DispatchQueue.main.async {
                    self.followerCountLabel.text = String(count)
                }
            }
        })
        
        
    }
    
    func loadFollowingUserIds() {
            let query = NCMBQuery(className: "follow")
            query?.includeKey("followingUser")
            query?.whereKey("user", equalTo: NCMBUser.current())

            query?.findObjectsInBackground({ (result, error) in
                if error != nil {
                    HUD.show(.labeledError(title: error!.localizedDescription, subtitle: nil))
                } else {
                    self.followingUserId = [String]()
                    for following in result as! [NCMBObject] {
                        let user = following.object(forKey: "following") as! NCMBUser
                        self.followingUserId.append(user.objectId)
                    }
                }
            })
        }
    
    //ログインユーザーがブロックしているユーザーのオブジェクトIDを格納する関数
    func getBlockUser(){
        //NCMBのBlockクラスのクエリを宣言
        let query = NCMBQuery(className: "Block")
        //検索結果にuserカラムの情報を含める
        query?.includeKey("user")
        //userカラムがログインユーザーと一致するレコードを取得
        query?.whereKey("user", equalTo: NCMBUser.current())
        query?.findObjectsInBackground({ (result, error) in
            if error != nil{
                HUD.flash(.labeledError(title: error?.localizedDescription, subtitle: nil), delay: 1)
            }else{
                //removeAll()で初期化をし、データの重複を防ぐ
                self.blockUserIdArray.removeAll()
                for blockObject in result as! [NCMBObject]{
                    //blockUserIdArrayに取得したレコードのblockUserIdカラムの要素のみを加える
                    self.blockUserIdArray.append(blockObject.object(forKey: "blockUserId") as! String)
                }
                //タイムラインを読み込みする
                self.loadTimeline()
            }
        })
    }
    
    func loadTimeline(){
        guard let currentUser = NCMBUser.current() else{
            
            let storyboard = UIStoryboard(name: "SignIn", bundle: Bundle.main)
            let rootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
            UIApplication.shared.windows.first { $0.isKeyWindow }?.rootViewController = rootViewController
            
            let ud = UserDefaults.standard
            ud.set(true, forKey: "isLogin")
            return
        }
        
        
        posts = [NCMBObject]()
        let query = NCMBQuery(className: "Declare")
        query?.order(byDescending: "createDate")
        query?.whereKey("user", equalTo: afterSelectedUser)
        query?.includeKey("user")
        query?.findObjectsInBackground({(result, error) in
            if error != nil{
                print(error)
            }else{
                
                for postObject in result as! [NCMBObject]{
                    let user = postObject.object(forKey: "user") as! NCMBUser
                    print(postObject)
                    if self.blockUserIdArray.firstIndex(of: user.objectId) == nil{
                        //postsっていう別の変数(箱)にデータを写変える文章
                        self.posts.append(postObject)
                    }
                    
                }
                self.selectedUserTableView.reloadData()
            }
        })

    }

    
  
    
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
