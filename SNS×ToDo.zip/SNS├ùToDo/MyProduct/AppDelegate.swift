//
//  AppDelegate.swift
//  MyProduct
//
//  Created by 田村 優奈 on 2022/09/30.
//

import UIKit
import NCMB
import SwiftUI
import EXTView


@main
class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate {


    var window: UIWindow?
    

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        NCMB.setApplicationKey("02455e4c2f14f4e3e6ff3b2cd1ebbfd7b2def55b7ea804f8afc288ca5da1692f", clientKey: "2e96b3b629027679e56cf060755723985144a32ea5f8da95afe54bb2e7836085")
        // Override point for customization after application launch.

        //通知許可の取得
        let center = UNUserNotificationCenter.current()
        center.requestAuthorization(options: [.alert, .badge, .sound]) {(granted, error) in
            if granted {
                print("許可する")
            } else {
                print("許可しない")
            }
        }
        setLocalNotification(title:"今日は納豆の日です", message:"oh! natto!で納豆を混ぜてみませんか？",month: 11, day: 5)
        
        let appearance = UITabBarAppearance()
        appearance.backgroundColor =  UIColor{_ in return #colorLiteral(red: 1, green: 0.6676921248, blue: 0.004999437369, alpha: 1)}
        UITabBar.appearance().tintColor = UIColor{_ in return #colorLiteral(red: 0.9499999881, green: 0.9499999881, blue: 0.9499999881, alpha: 1)}
        
        UITabBar.appearance().standardAppearance = appearance
        UITabBar.appearance().scrollEdgeAppearance = appearance
       
        let navigationAppearance = UINavigationBarAppearance()
        navigationAppearance.backgroundColor = UIColor{_ in return #colorLiteral(red: 1, green: 0.8551200628, blue: 0.5739368796, alpha: 1)}
        UINavigationBar.appearance().standardAppearance = navigationAppearance
        UINavigationBar.appearance().scrollEdgeAppearance = navigationAppearance
        
        sleep(2)

        return true
        
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    
    private func setLocalNotification(title:String = "", message:String, month: Int, day: Int,hour:Int = 20, minute:Int = 23, second:Int = 0 ){
            // タイトル、本文、サウンド設定の保持
            let content = UNMutableNotificationContent()
            content.title = title
            content.body = message
            content.sound = UNNotificationSound.default
            
            var notificationTime = DateComponents()
            notificationTime.month = month
            notificationTime.day = day
            notificationTime.hour = hour
            notificationTime.minute = minute
            notificationTime.second = second
            
            let trigger: UNNotificationTrigger = UNCalendarNotificationTrigger(dateMatching: notificationTime, repeats: false)
            
            // 識別子とともに通知の表示内容とトリガーをrequestに内包
            let request = UNNotificationRequest(identifier: "Natto", content: content, trigger: trigger)
            
            // UNUserNotificationCenterにrequestを加える
            let center = UNUserNotificationCenter.current()
            center.delegate = self
            center.add(request) { (error) in
                if let error = error {
                    print(error.localizedDescription)
                }
            }
        let lcNotification = UNUserNotificationCenter.current()
        lcNotification.removeAllPendingNotificationRequests()

    }
            func userNotificationCenter(
                _ center: UNUserNotificationCenter,
                willPresent notification: UNNotification,
                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void)
            {
                // アプリ起動時も通知を行う
                completionHandler([ .badge, .sound, .alert ])
            }
        
        

}

