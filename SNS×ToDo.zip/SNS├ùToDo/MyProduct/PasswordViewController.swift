//
//  PasswordViewController.swift
//  MyProduct
//
//  Created by Nyappi on 2022/10/05.
//

import UIKit
import NCMB
import PKHUD


class PasswordViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet var passwordChangeLabel: UILabel!
    @IBOutlet var searchAccountLabel: UILabel!
    @IBOutlet var mailAddressTextField: UITextField!
    @IBOutlet var nextButton: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        mailAddressTextField.delegate = self
        self.nextButton.layer.cornerRadius = 10
        
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
    }
    
    @IBAction func resetPassword() {
        let result = NCMBUser.requestPasswordResetForEmail(inBackground: mailAddressTextField.text) {
             (error) in
            if error != nil {
                print("error")
            }else{
                print("success")
            }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
