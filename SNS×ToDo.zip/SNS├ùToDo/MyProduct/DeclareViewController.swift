//
//  DeclareViewController.swift
//  MyProduct
//
//  Created by Nyappi on 2022/10/09.
//

import UIKit
import NCMB
import PKHUD

class DeclareViewController: UIViewController, UITextViewDelegate, UINavigationControllerDelegate {
    
    let placeholderImage = UIImage(named: "photo-placeholder")
    
                                   
    
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var declareTextView: UITextView!
    @IBOutlet weak var declareButton: UIButton!
    @IBOutlet weak var timeLimitPicker: UIDatePicker!
    @IBOutlet weak var cancelBarButton: UIBarButtonItem!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    var tweet: Bool! = false
    var comments = [NCMBObject]()
    var postId: String!
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        userImageView.layer.cornerRadius = userImageView.bounds.width / 2
        
        declareButton.isEnabled = false
        declareTextView.delegate = self
        
        segmentedControl.selectedSegmentIndex = 0
        segmentedControl.backgroundColor = UIColor{_ in return #colorLiteral(red: 1, green: 0.7203107476, blue: 0.1185235903, alpha: 1)}
        self.declareButton.layer.cornerRadius = 20
        
      
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let user = NCMBUser.current() {
            //NCMBFileからuserIdが結合しているimagefileをゲットする
            let file = NCMBFile.file(withName: (user.objectId)!, data: nil) as! NCMBFile
            file.getDataInBackground{ (data, error) in
                if error != nil{
                    print(error.debugDescription)
                    return
                }
            //取得したimageを反映
                if let image = UIImage(data: data!) {
                    self.userImageView.image = image
                }
            }
        }
        
    }
    
    func confirmContent() {
        if declareTextView.text.count > 0 {
            declareButton.isEnabled = true
        }else{
            declareButton.isEnabled = false
        }
    }
    
    func textViewDidChange(_ textView: UITextView) {
        confirmContent()
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        textView.resignFirstResponder()
    }
    
    @IBAction func declare(_ sender: Any) {
        //インジケーターを開始
        HUD.show(.progress, onView: self.view)
        
        let declareObject = NCMBObject(className: "Declare")
        let appId = "BAv7MRjuGKuR33Jj"
        let url = "https://mbaas.api.nifcloud.com/2013-09-01/applications/" + appId
        
        let format = DateFormatter()
        format.dateFormat = "yyyy/MM/dd HH:mm"
        let stringDate = format.string(from: timeLimitPicker.date)
        declareObject?.setObject(stringDate, forKey: "date")
        declareObject?.setObject(self.declareTextView.text, forKey: "text")
        declareObject?.setObject(NCMBUser.current(), forKey: "user")
        declareObject?.setObject("true", forKey: "delete")
        declareObject?.setObject(url, forKey: "textUrl")
        if tweet {
            declareObject?.setObject("Boyaki", forKey: "tweet")
        }else{
            declareObject?.setObject("Declare", forKey: "tweet")
        }
        declareObject?.saveInBackground ({ (error) in
            if error != nil{
                print(error.debugDescription)
                return
            }
            //インジケーター停止
            HUD.hide(animated: true)
            
            //保存成功⇨元に戻す
            self.declareTextView.text = nil
            self.tabBarController?.selectedIndex = 0
            
        })
        
        //メインストーリーボードに戻る
        let storyboard = UIStoryboard(name: "Main", bundle: .main)
        let rootVC = storyboard.instantiateViewController(identifier: "RootTabBarController")
        //モーダルをフルスクリーン表示
        rootVC.modalPresentationStyle = .fullScreen
        //画面表示
        self.present(rootVC, animated: true, completion: nil)
        
    }
    
    @IBAction func cancelAction () {
        if declareTextView.isFirstResponder == true {
            declareTextView.resignFirstResponder()
        }
        let alert = UIAlertController(title: "投稿内容の破棄", message: "入力内容を破棄しますか？", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: { (action) in
            self.declareTextView.text = nil
            self.confirmContent()
            //アラートが消えるのと画面遷移が重ならないように0.5秒後に画面遷移するようにしてる
                       DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        // 0.5秒後に実行したい処理
//                           self.performSegue(withIdentifier: "cancel", sender: nil)
                           self.tabBarController?.selectedIndex = 0
                        }
                       
        })
        let cancelAction = UIAlertAction(title: "キャンセル", style: .cancel, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
        })
        
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func tappedSegmentedControl(_ sender: UISegmentedControl) {
        
        switch sender.selectedSegmentIndex{
        case 0:
            timeLimitPicker.isHidden = false
            tweet = false
            
            
        case 1:
            timeLimitPicker.isHidden = true
            tweet = true
            
        default:
            timeLimitPicker.isHidden = false
            tweet = false
            
        }
    
        
    }
   
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
