//
//  SignInViewController.swift
//  MyProduct
//
//  Created by Nyappi on 2022/10/02.
//

import UIKit
import NCMB
import PKHUD


class SignInViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet var userNameTextField: UITextField!
    @IBOutlet var passWordTextField: UITextField!
    @IBOutlet var logInButton: UIButton!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        userNameTextField.delegate = self
        passWordTextField.delegate = self
        self.logInButton.layer.cornerRadius = 10
        // Do any additional setup after loading the view.
    }
    
    //キーボードを閉じる
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
        
    }
    
    @IBAction func signIn(){
        HUD.show(.progress)
        NCMBUser.logInWithUsername(inBackground: userNameTextField.text!, password: passWordTextField.text!){ (user, error) in
            if error != nil{
                HUD.hide(animated: true)
                            print(error)
            }else{
                HUD.hide(animated: true)
                let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
                let rootViewController = storyboard.instantiateViewController(withIdentifier: "RootTabBarController")
                UIApplication.shared.windows.first { $0.isKeyWindow }?.rootViewController = rootViewController
                //ログイン状態を保持する
                let ud = UserDefaults.standard
                ud.set(true, forKey: "isLogin")
                
            }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
