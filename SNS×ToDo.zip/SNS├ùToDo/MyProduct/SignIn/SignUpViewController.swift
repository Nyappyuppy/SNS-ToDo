//
//  SignUpViewController.swift
//  MyProduct
//
//  Created by Nyappi on 2022/10/02.
//

import UIKit
import NCMB



class SignUpViewController: UIViewController, UITextFieldDelegate{
    @IBOutlet var userNameTextField: UITextField!
    @IBOutlet var mailAddressTextField: UITextField!
    @IBOutlet var passWordTextField: UITextField!
    @IBOutlet var confirmPassWordTextField: UITextField!
    @IBOutlet var signUpButton: UIButton!
    var alertController: UIAlertController!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        userNameTextField.delegate = self
        mailAddressTextField.delegate = self
        passWordTextField.delegate = self
        confirmPassWordTextField.delegate = self
        self.signUpButton.layer.cornerRadius = 10
        
        // Do any additional setup after loading the view.
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //キーボードを閉じる
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func signUp(){
        //どれか一つでもテキストフィールドが埋まってなければサインアップ処理を行わない
        if userNameTextField.text?.count == 0 || mailAddressTextField.text?.count == 0 || passWordTextField.text!.count <= 7 || confirmPassWordTextField.text!.count <= 7 || (passWordTextField.text != confirmPassWordTextField.text){
            return
        }else if mailAddressTextField.text?.contains("@") == false{
            alertController = UIAlertController(title: "@が見つかりません",
                                                message: "メールアドレスを入力してください",
                                                preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default){ (action) in
            }
            alertController.addAction(okAction)
            present(alertController, animated: true)
            return
            
        }
        let user = NCMBUser()
        user.userName = userNameTextField.text!
        user.mailAddress = mailAddressTextField.text!
        user.password = passWordTextField.text!
        var acl = NCMBACL()
        //読み込み・検索を全開放（ACLの設定で全員から参照できるようにする）
        acl.setPublicReadAccess(true)
        acl.setPublicWriteAccess(true)
        user.acl = acl
        //ユーザーが退会済みかを判定する。退会済み＝false
        user.setObject(true, forKey: "active")
        user.setObject("", forKey: "displayName")
        user.signUpInBackground{ (error) in
            if error != nil{
                print(error)
            }else{
                //ログインしたら画面遷移
                let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
                let rootViewController = storyboard.instantiateViewController(withIdentifier: "RootTabBarController")
                UIApplication.shared.windows.first { $0.isKeyWindow }?.rootViewController = rootViewController
                //ログイン状態を保持
                let ud = UserDefaults.standard
                ud.set(true, forKey: "isLogin")
            }
                
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
