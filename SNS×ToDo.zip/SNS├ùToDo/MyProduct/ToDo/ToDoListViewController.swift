//
//  ToDoListViewController.swift
//  MyProduct
//
//  Created by Nyappi on 2022/10/17.
//

import UIKit
import NCMB
import SwiftUI
import CoreMedia

class ToDoListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, ToDoTableViewCellDelegate {
    
    var todoList = [String]()
    var posts = [NCMBObject]()
    var selectedTodo: NCMBObject!
    var delete: Bool = false
   
    
    @IBOutlet weak var toDoListTableView: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        toDoListTableView.dataSource = self
        toDoListTableView.delegate = self
        
        let ud = UserDefaults.standard
        if let storedTodoList = ud.array(forKey: "todoList") as? [String] {
                todoList.append(contentsOf: storedTodoList)
            }
        // カスタムセルの登録
        let nib = UINib(nibName: "ToDoTableViewCell", bundle: Bundle.main)
        toDoListTableView.register(nib, forCellReuseIdentifier: "todoCell")
        // 余計な線を消す
        toDoListTableView.tableFooterView = UIView()
        toDoListTableView.rowHeight = 60
        
        setRefreshControl()
        
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(true)
        if delete == false{
            loadTimeline()
        }
       
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let todoCell = tableView.dequeueReusableCell(withIdentifier: "todoCell", for: indexPath) as! ToDoTableViewCell
        
        let user = posts[indexPath.row].object(forKey: "user") as! NCMBUser

        
        let userObjectId = user.object(forKey: "objectId") as! String
        let appId = "BAv7MRjuGKuR33Jj"
        let userImageUrl = "https://mbaas.api.nifcloud.com/2013-09-01/applications/" + appId + "/publicFiles/" + userObjectId
        
        todoCell.delegate = self
        todoCell.tag = indexPath.row
        
        todoCell.timeLimitLabel.text = posts[indexPath.row].object(forKey: "date") as? String
        todoCell.taskLabel.text = posts[indexPath.row].object(forKey: "text") as! String
        

     //   todoCell.timeLimitLabel.backgroundColor = UIColor{_ in return #colorLiteral(red: 1, green: 0.69816643, blue: 0.7065266967, alpha: 1)}
//        todoCell.timeLimitLabel.layer.borderColor = UIColor{_ in return #colorLiteral(red: 1, green: 0.69816643, blue: 0.7065266967, alpha: 1)}.cgColor
//        todoCell.timeLimitLabel.layer.borderWidth = 5
        
        todoCell.timeLimitLabel.layer.cornerRadius = 20
        return todoCell
    }
  
    
    func setRefreshControl() {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(reloadTimeline(refreshControl:)), for: .valueChanged)
        toDoListTableView.addSubview(refreshControl)
        
    }
    @objc func reloadTimeline(refreshControl: UIRefreshControl){
        refreshControl.beginRefreshing()
        if delete == false{
            self.loadTimeline()
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                refreshControl.endRefreshing()
            }
        }
    }
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "toDoDetail", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toDoDetail" {
            
            // 値渡し先の画面を取得
            let detailViewController = segue.destination as! DetailViewController

            // タップされたセルが何番目なのかを取得
            let selectedIndex = toDoListTableView.indexPathForSelectedRow!

            // 値渡し先の画面に用意しておいた受け取り用の変数にメモを代入
            detailViewController.selectedTodo = posts[selectedIndex.row]
            
        }
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
           
              // アイテム削除処理
              posts.remove(at: indexPath.row)
        
              let indexPaths = [indexPath]
              tableView.deleteRows(at: indexPaths, with: .automatic)

            let query = NCMBQuery(className: "Declare")
            query?.whereKey("delete", equalTo: "true")
        query?.order(byDescending: "createDate")
            query?.findObjectsInBackground({ (result, error) in
                if error != nil{
                    print(error)
                }else{
                    let messages = result as! [NCMBObject]
                    let textObject = messages[indexPath.row]
                    textObject.setObject("false", forKey: "delete")
                    
                    textObject.saveInBackground{ (error) in
                        if error != nil{
                            print(error)
                        }else{
                            print("Update Success!!")
                        }
                    }
                }
                
            })
        
        
        
        
//            UserDefaults.standard.removeObject(forKey: "")
         
//
//        let query = NCMBQuery(className: "Declare")
//        query?.findObjectsInBackground({ (result, error) in
//            if error != nil{
//                print(error)
//            } else {
//                let messages = result as! [NCMBObject]
//
//                // 配列の最初の要素(0番目)を表示
//                let textObject = messages[0]
//                // 削除を実行
//                textObject.deleteInBackground { (error) in
//                if error != nil {
//                        print(error)
//                        } else {
//                            print("Delete succeed")
//                                    }
//                                }
//                            }
//                        })
//            }
    }
    
    
    func loadTimeline(){
        guard let currentUser = NCMBUser.current() else{
            
            let storyboard = UIStoryboard(name: "SignIn", bundle: Bundle.main)
            let rootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
            UIApplication.shared.windows.first { $0.isKeyWindow }?.rootViewController = rootViewController
            
            let ud = UserDefaults.standard
            ud.set(true, forKey: "isLogin")
            return
        }
        
        posts = [NCMBObject]()
        let query = NCMBQuery(className: "Declare")
        query?.order(byDescending: "createDate")
        query?.whereKey("delete", equalTo: "true")
        query?.includeKey("user")
        query?.whereKey("user", equalTo: NCMBUser.current())
        query?.whereKey("tweet", equalTo: "Declare")
        query?.findObjectsInBackground({(result, error) in
            if error != nil{
                print(error)
            }else{
                
                for postObject in result as! [NCMBObject]{
                    let user = postObject.object(forKey: "user") as! NCMBUser
                    print(postObject)
                    if user.object(forKey: "active") as? Bool != false{
                        self.posts.append(postObject)
                    }
                }
                self.toDoListTableView.reloadData()
            }
        })
    }
    
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
