//
//  DetailViewController.swift
//  MyProduct
//
//  Created by Nyappi on 2022/10/19.
//

import UIKit
import NCMB


class DetailViewController: UIViewController {

    var selectedTodo: NCMBObject!
    
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var todoTextView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        timeLabel.text = selectedTodo.object(forKey: "date") as? String
        todoTextView.text = selectedTodo.object(forKey: "text") as! String
        

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
