//
//  ToDoTableViewCell.swift
//  MyProduct
//
//  Created by Nyappi on 2022/10/17.
//

import UIKit
import NCMB

protocol ToDoTableViewCellDelegate{
    
}

class ToDoTableViewCell: UITableViewCell {
    
    @IBOutlet weak var timeLimitLabel: UILabel!
    @IBOutlet weak var taskLabel: UILabel!
    
    var posts = [NCMBObject]()
    var delegate: ToDoTableViewCellDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
}
