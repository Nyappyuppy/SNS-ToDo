//
//  SelectedUserTableViewCell.swift
//  MyProduct
//
//  Created by Nyappi on 2022/10/21.
//

import UIKit
import NCMB

protocol SelectedUserTableViewCellDelegate {
    func didTapFavoriteButton(targetcell: UITableViewCell, targetButton: UIButton)
    func didTapCommentButton(targetcell: UITableViewCell, targetButton: UIButton)
    func didTapMenuButton(targetCell: UITableViewCell,targetButton: UIButton)
    
}

class SelectedUserTableViewCell: UITableViewCell {
    
    
    var delegate: SelectedUserTableViewCellDelegate?
    var favoriteNumber: Int = 0
    var commentNumber: Int = 0
    var ud = UserDefaults.standard
    
    
    @IBOutlet var userImageView: UIImageView!
    @IBOutlet var userNameLabel: UILabel!
    @IBOutlet var declareTextView: UITextView!
    @IBOutlet var favoriteButton: UIButton!
    @IBOutlet var favoriteCountLabel: UILabel!
    @IBOutlet var commentButton: UIButton!
    @IBOutlet var commentCountLabel: UILabel!
    @IBOutlet var timestampLabel: UILabel!
    @IBOutlet var timeLimitLabel: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        userImageView.layer.cornerRadius = userImageView.bounds.width/2.0
                userImageView.clipsToBounds = true
        
        let number = ud.integer(forKey: "likeCount")
        favoriteNumber = favoriteNumber + number
        favoriteCountLabel.text = String(number)
        print(favoriteNumber, "ooooo")
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func favorite(button: UIButton) {
        self.delegate?.didTapFavoriteButton(targetcell: self, targetButton: button)
    }

    @IBAction func showComment(button: UIButton) {
        self.delegate?.didTapCommentButton(targetcell: self, targetButton: button)
        
    }
   
    
    @IBAction func openMenu(button: UIButton){
        self.delegate?.didTapMenuButton(targetCell: self, targetButton: button)
        
    }
    
}


