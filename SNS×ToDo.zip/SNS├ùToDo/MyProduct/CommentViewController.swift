//
//  CommentViewController.swift
//  MyProduct
//
//  Created by Nyappi on 2022/11/09.
//
import UIKit
import NCMB
import PKHUD
import Kingfisher


class CommentViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var postId: String!
    var posts = [NCMBObject]()
    var comments = [NCMBObject]()
    
    @IBOutlet var commentTableView: UITableView!
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        commentTableView.dataSource = self
        commentTableView.rowHeight = 300
        commentTableView.tableFooterView = UIView()
        
        
        loadComments()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return comments.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CommentCell")!
        let userImageView = cell.viewWithTag(1) as! UIImageView
        let userNameLabel = cell.viewWithTag(2) as! UILabel
        let commentTextView = cell.viewWithTag(3) as? UITextView
        
        userImageView.layer.cornerRadius = userImageView.bounds.width / 2.0
        userImageView.layer.masksToBounds = true
        
        let user = comments[indexPath.row].object(forKey: "user") as! NCMBUser
       // let postId = comments[indexPath.row].object(forKey: "postId") as! String
        let appId = "BAv7MRjuGKuR33Jj"
        let userImagePath = "https://mbaas.api.nifcloud.com/2013-09-01/applications/" + appId + "/publicFiles/" + user.objectId
        userImageView.kf.setImage(with: URL(string: userImagePath))
        userNameLabel.text = user.object(forKey: "userName") as! String
        commentTextView?.text = comments[indexPath.row].object(forKey: "text") as! String
        
        let mainViewController = ViewController()
        let comecomment = comments[indexPath.row].object(forKey: "postId") as? String
       
        print(comments, "🐱🐱🐱")
        
        return cell
    }
    
    func tableVIew(_ tableView: UITableView, heightForRowAt indePath: IndexPath) -> CGFloat {
        //可変セルの設定
        //オートレイアウトの縦軸が全て繋がっていないと計算されない
        commentTableView.estimatedRowHeight = 688
        return UITableView.automaticDimension
    }
    

    
    
    
    //コメント読み込み
    func loadComments(){
       // comments = [NCMBObject]()
       //
        HUD.show(.progress, onView: self.view)
//
        let query = NCMBQuery(className: "Comment")
        query?.whereKey("postId", equalTo: postId)
        query?.includeKey("user")
        query?.findObjectsInBackground({ (result,error) in
            if error != nil{
                HUD.hide(animated: true)
            }else{
                HUD.hide(animated: true)

                for commentObject in result as! [NCMBObject] {

                    //コメントの文字を取得
                    let text = commentObject.object(forKey: "text") as? String
                    self.comments.append(commentObject)
                    
                   
                }
                //テーブルをリロード
                self.commentTableView.reloadData()
            }
        })
    }
    
//    //コメントを追加
    @IBAction func addComment() {
        let alert = UIAlertController(title: "コメント", message: "コメントを入力してください", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "キャンセル", style: .default) { (action) in
            alert .dismiss(animated: true, completion: nil)
        }
        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
            alert.dismiss(animated: true, completion: nil)
            HUD.show(.progress, onView: self.view)
            HUD.show(.progress, onView: self.view)
            //
            //
          
            let object = NCMBObject(className: "Comment")
            object?.setObject(self.postId, forKey: "postId")
            object?.setObject(NCMBUser.current(), forKey: "user")
            object?.setObject(alert.textFields?.first?.text, forKey: "text")
            object?.saveInBackground({ (error) in
                if error != nil {
                    print(error)
                    HUD.hide(animated: true)
                }else{
                    HUD.hide(animated: true)
                    self.loadComments()
                }
            })
        }
        alert.addAction(cancelAction)
        alert.addAction(okAction)
        alert.addTextField{ (textField) in
            textField.placeholder = "コメントを入力"
        }
        self.present(alert, animated: true, completion: nil)
    }
//
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

