//
//  ProfileViewController.swift
//  MyProduct
//
//  Created by Nyappi on 2022/10/05.
//

import UIKit
import NCMB
import PKHUD
import Kingfisher

class ProfileViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, MyTimelineTableViewCellDelegate, TimelineTableViewCellDelegate {
  
    
  
    var selectedPost: NCMBObject?
    var selectedUser: NCMBUser?
    var posts = [NCMBObject]()
    var follow = [NCMBObject]()
    var followings = [NCMBUser]()
    var users = [NCMBUser]()
    var user = NCMBUser.current()
    var ud = UserDefaults.standard
    
    
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var introductionTextView: UITextView!
    @IBOutlet weak var followCountLabel: UILabel!
    @IBOutlet weak var followerCountLabel: UILabel!
    @IBOutlet weak var profileEditButton: UIButton!
    @IBOutlet weak var myTimelineTableView: UITableView!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        //プロフィール画像の角を丸くする
        userImageView.layer.cornerRadius = userImageView.bounds.width / 2
        
        guard let currentUser = NCMBUser.current() else {
                   //ログインに戻る
                   //ログアウト登録成功
                   let storyboard = UIStoryboard(name: "SignIn", bundle: Bundle.main)
                   let RootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
                   UIApplication.shared.keyWindow?.rootViewController = RootViewController
                   //ログアウト状態の保持
                   let ud = UserDefaults.standard
                   ud.set(false, forKey: "isLogin")
                   ud.synchronize()
                   return
            
               }
        
        let number = ud.integer(forKey: "likeCount")
        
        
        myTimelineTableView.dataSource = self
        myTimelineTableView.delegate = self
        myTimelineTableView.rowHeight = 400
        
        
        profileEditButton.layer.borderColor = UIColor.systemGray3.cgColor
        profileEditButton.layer.borderWidth = 1
        profileEditButton.layer.cornerRadius = 20
        profileEditButton.backgroundColor = UIColor{_ in return #colorLiteral(red: 0.4016079903, green: 0.7575066686, blue: 0.7143911123, alpha: 1)}
        profileEditButton.tintColor = UIColor.white
        
        let nib = UINib(nibName: "MyTimelineTableViewCell", bundle: Bundle.main)
        myTimelineTableView.register(nib, forCellReuseIdentifier:"MyTimelineCell")
        myTimelineTableView.tableFooterView = UIView()

        setRefreshControl()
        loadFollowingInfo()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
        if let user = NCMBUser.current() {
            userNameLabel.text = user.object(forKey: "userName") as? String
            introductionTextView.text = user.object(forKey: "introduction") as? String
            //navigationBarのタイトルにuserIdを反映
            //self.navigationItem.title = user.userName
            
            //NCMBFileからuserIdが結合しているimagefileをゲットする
            let file = NCMBFile.file(withName: (user.objectId)!, data: nil) as! NCMBFile
            file.getDataInBackground{ (data, error) in
                if error != nil{
                    print(error.debugDescription)
                    return
                }
            //取得したimageを反映
                if let image = UIImage(data: data!) {
                    self.userImageView.image = image
                }
            }
        }else{
            //NCMBUser.currentがnilの場合＝有効期限切れ⇨ログインし直させる
            //遷移先ストーリーボードを取得
            let storyboard = UIStoryboard(name: "SignIn", bundle: .main)
            let rootVC = storyboard.instantiateViewController(identifier: "RootNavigationController")
            //モーダルをフルスクリーン表示
            rootVC.modalPresentationStyle = .fullScreen
            //画面表示
            self.present(rootVC, animated: true, completion: nil)
            
            //ログアウト状態を端末に保持
            let ud = UserDefaults.standard
            ud.set(false, forKey: "isLogin")
            
        }
        let searchUserViewController = SearchUserViewController()
//        followCountLabel.text = follow.object(forKey: "user") as? String
//        followerCountLabel.text =
        loadTimeline()
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toComment" {
            let commentViewController = segue.destination as! CommentViewController
            print(selectedPost?.objectId)
            commentViewController.postId = selectedPost?.objectId as! String
        }
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let myTimelineCell = tableView.dequeueReusableCell(withIdentifier: "MyTimelineCell") as! MyTimelineTableViewCell

        myTimelineCell.delegate = self
        myTimelineCell.tag = indexPath.row
        let user = posts[indexPath.row].object(forKey: "user") as! NCMBUser

        if user.object(forKey: "userName") as! String != "" {
            myTimelineCell.userNameLabel.text = user.object(forKey: "userName") as! String
        }else{
           myTimelineCell.userNameLabel.text = "表示名なし"
        }
        let userObjectId = user.object(forKey: "objectId") as! String
        let appId = "BAv7MRjuGKuR33Jj"
        let userImageUrl = "https://mbaas.api.nifcloud.com/2013-09-01/applications/" + appId + "/publicFiles/" + userObjectId

        myTimelineCell.userImageView.kf.setImage(with: URL(string: userImageUrl), placeholder: UIImage(systemName: "person"), options: nil, progressBlock: nil)

        myTimelineCell.declareTextView.text = posts[indexPath.row].object(forKey: "text") as! String
        myTimelineCell.favoriteButton.tintColor = UIColor{_ in return #colorLiteral(red: 1, green: 0.6676921248, blue: 0.004999437369, alpha: 1)}
        myTimelineCell.commentButton.tintColor = UIColor{_ in return #colorLiteral(red: 1, green: 0.6676921248, blue: 0.004999437369, alpha: 1)}
        
        if posts[indexPath.row].object(forKey: "tweet") as? String == "Declare" || posts[indexPath.row].object(forKey: "tweet") as? [String] == []{
            print("SEN")
            myTimelineCell.timeLimitLabel.text = posts[indexPath.row].object(forKey: "date") as? String
        }else{
            print("BOYA")
            myTimelineCell.timeLimitLabel.isHidden = true
        }
        let likeUsers = posts[indexPath.row].object(forKey: "likeUser") as? [String] ?? []
        if likeUsers.contains(NCMBUser.current()?.objectId as! String) == false {
                    myTimelineCell.favoriteButton.setImage(UIImage(systemName: "heart"),for: .normal)
                }else{
                    myTimelineCell.favoriteButton.setImage(UIImage(systemName: "heart.fill"),for: .normal)
                }
        myTimelineCell.favoriteCountLabel.text = "\(likeUsers.count)"
        
        let df = DateFormatter()
        df.dateFormat = "yyyy/MM/dd HH:mm"
        let date = posts[indexPath.row].createDate as! Date
        myTimelineCell.timestampLabel.text = df.string(from: date)
        return myTimelineCell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
            selectedPost = posts[indexPath.row]
        tableView.deselectRow(at: indexPath, animated: true)
        
       
    }
    
    func didTapFavoriteButton(targetcell tableViewCell: UITableViewCell, targetButton button: UIButton) {
        guard let currentUser = NCMBUser.current() else{
            let storyboard = UIStoryboard(name: "SignIn", bundle: Bundle.main)
            let rootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
            UIApplication.shared.windows.first{ $0.isKeyWindow }?.rootViewController = rootViewController
            
            let ud = UserDefaults.standard
            ud.set(true, forKey: "isLogin")
            ud.synchronize()
            return
            
        }
        let favoriteUsers = posts[tableViewCell.tag].object(forKey: "likeUser") as? [String]
        HUD.show(.progress, onView: self.view)
        
        if favoriteUsers?.contains((NCMBUser.current()?.objectId)!) == false || favoriteUsers == nil {
                   //ボタンを押す前にいいねしてなかったら
                   posts[tableViewCell.tag].addUniqueObject(currentUser.objectId, forKey: "likeUser")
                   posts[tableViewCell.tag].saveEventually { error in
                       HUD.hide(animated: true)
                       if error != nil{
                           print(error)
                       }else{
                           self.loadTimeline()
                       }
                   }
               } else {
                   //ボタンを押す前にいいねしていたら
                  posts[tableViewCell.tag].removeObjects(in: [NCMBUser.current().objectId], forKey: "likeUser")
                  posts[tableViewCell.tag].saveEventually { error in
                       HUD.hide(animated: true)
                       if error != nil{
                           print(error)
                       }else{
                           self.loadTimeline()
                       }
                   }
               }
        
       
//            let query = NCMBQuery(className: "Declare")
//            query?.getObjectInBackground(withId: posts[tableViewCell.tag].objectId, block: { (declare,error) in
//                declare?.addUniqueObject(currentUser.objectId, forKey: "likeUser")
//                declare?.saveEventually({ (error) in
//                    HUD.hide(animated: true)
//                    if error != nil{
//                        print(error)
//                    } else {
//                        self.loadTimeline()
//                    }
//                })
//            })
        
    }
    
    func didTapCommentButton(targetcell tableViewCell: UITableViewCell, targetButton button: UIButton) {
        selectedPost = posts[tableViewCell.tag]
        self.performSegue(withIdentifier: "toComment", sender: nil)
        
        guard let currentUser = NCMBUser.current() else{
            let storyboard = UIStoryboard(name: "SignIn", bundle: Bundle.main)
            let rootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
            UIApplication.shared.windows.first{ $0.isKeyWindow }?.rootViewController = rootViewController

            let ud = UserDefaults.standard
            ud.set(true, forKey: "isLogin")
            ud.synchronize()
            return
//
        }
//
//        let commentUsers = posts[tableViewCell.tag].object(forKey: "commentUser") as? [String]
//        HUD.show(.progress, onView: self.view)
////
////
//            let query = NCMBQuery(className: "Declare")
//            query?.getObjectInBackground(withId: posts[tableViewCell.tag].objectId, block: { (declare,error) in
//                declare?.addUniqueObject(currentUser.objectId, forKey: "commentUser")
//                declare?.saveEventually({ (error) in
//                    if error != nil{
//                        print(error)
//                    } else {
//                        //成功した時に消す
//                        HUD.hide(animated: true)
//
//                        print("roiroiroi")
//                    }
//                })
//            })
    }
    
    
    
    func didTapMenuButton(targetcell tableViewCell: UITableViewCell, targetButton: UIButton) {
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        let cancelAction = UIAlertAction(title: "キャンセル", style: .cancel){ (action) in
            alertController.dismiss(animated: true, completion: nil)
            
        }
        let deleteAction = UIAlertAction(title: "削除する", style: .destructive){ (action) in
            HUD.show(.progress, onView: self.view)
            let query = NCMBQuery(className: "Declare")
            query?.getObjectInBackground(withId: self.posts[tableViewCell.tag].objectId, block: {(post, error) in
                if error != nil{
                    print(error)
                }else{
                    // 取得した投稿オブジェクトを削除
                    post?.deleteInBackground({ (error) in
                        if error != nil{
                            print(error)
                        }else{
                            //再読み込み
                            self.loadTimeline()
                            //読み込み(HUD)を直ちに消去する
                            HUD.hide(animated: true)
                        }
                    })
                }
            })
        }
        alertController.addAction(deleteAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
       
    
    
    
    func loadFollowingInfo() {
        //フォロー
        let followingQuery = NCMBQuery(className: "follow")
        followingQuery?.includeKey("user")
        followingQuery?.whereKey("user", equalTo: NCMBUser.current())
        followingQuery?.whereKey("following", equalTo: "true")
        followingQuery?.countObjectsInBackground({ (count, error) in
            if error != nil{
                print(error)
//                KRProgressHUD.showError(withMessage: error!.localizedDescription)
            }else{
                DispatchQueue.main.async {
                    self.followCountLabel.text = String(count)
                }
            }
        })
        
        //フォロワー
        let followerQuery = NCMBQuery(className: "follow")
        followerQuery?.includeKey("followingUser")
        followerQuery?.whereKey("followingUser", equalTo: NCMBUser.current())
        followerQuery?.whereKey("following", equalTo: "true")
        followerQuery?.countObjectsInBackground({ (count, error) in
            if error != nil{
                print(error)
//                KRProgressHUD.showError(withMessage: error!.localizedDescription)
            }else{
                DispatchQueue.main.async {
                    self.followerCountLabel.text = String(count)
                }
            }
        })
        
        
    }
    
    func setRefreshControl() {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(reloadTimeline(refreshControl:)), for: .valueChanged)
        myTimelineTableView.addSubview(refreshControl)
    }
    @objc func reloadTimeline(refreshControl: UIRefreshControl){
        refreshControl.beginRefreshing()
        self.loadTimeline()
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            refreshControl.endRefreshing()
        }
    }
    
    func loadTimeline(){
        guard let currentUser = NCMBUser.current() else{
            
            let storyboard = UIStoryboard(name: "SignIn", bundle: Bundle.main)
            let rootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
            UIApplication.shared.windows.first { $0.isKeyWindow }?.rootViewController = rootViewController
            
            let ud = UserDefaults.standard
            ud.set(true, forKey: "isLogin")
            return
        }
        posts = [NCMBObject]()
        let query = NCMBQuery(className: "Declare")
        query?.order(byDescending: "createDate")
        query?.whereKey("user", equalTo: NCMBUser.current())
        query?.includeKey("user")
        query?.findObjectsInBackground({(result, error) in
            if error != nil{
                print(error)
            }else{
                
                for postObject in result as! [NCMBObject]{
                    let user = postObject.object(forKey: "user") as! NCMBUser
                    print(postObject)
                    if user.object(forKey: "active") as? Bool != false{
                        self.posts.append(postObject)
                    }
                }
                self.myTimelineTableView.reloadData()
            }
        })

    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
