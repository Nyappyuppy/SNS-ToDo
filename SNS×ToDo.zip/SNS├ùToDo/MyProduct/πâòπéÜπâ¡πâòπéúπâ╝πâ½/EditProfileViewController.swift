//
//  ProfileChangeViewController.swift
//  MyProduct
//
//  Created by Nyappi on 2022/10/05.
//

import UIKit
import NCMB
import AVFoundation


class ProfileChangeViewController: UIViewController, UITextFieldDelegate, UITextViewDelegate,UIImagePickerControllerDelegate,   UINavigationControllerDelegate{

    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var introductionTextView: UITextView!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var keepButton: UIButton!
    @IBOutlet weak var profileImageChangeButton: UIButton!
    @IBOutlet weak var logoutButton: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        userNameTextField.delegate = self
        introductionTextView.delegate = self
        
        if let user = NCMBUser.current(){
            userNameTextField.text = user.object(forKey: "userName") as! String
            introductionTextView.text = user.object(forKey: "introduction") as? String
        }
        self.introductionTextView.layer.borderColor = UIColor.systemGray5.cgColor
        self.introductionTextView.layer.borderWidth = 1
        self.introductionTextView.layer.cornerRadius = 5
        
        userImageView.backgroundColor = UIColor{_ in return #colorLiteral(red: 0.8823529412, green: 0.8823529412, blue: 0.8823529412, alpha: 1)}
        userImageView.layer.borderColor = UIColor{_ in return #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)}.cgColor
        userImageView.layer.borderWidth = 2
       // logoutButton.backgroundColor = UIColor{_ in return #colorLiteral(red: 0.2678219974, green: 0.6523951292, blue: 0.9751954675, alpha: 1)}
        logoutButton.tintColor = UIColor{_ in return #colorLiteral(red: 0.1025306061, green: 0.5094957948, blue: 1, alpha: 1)}
        logoutButton.backgroundColor = UIColor{_ in return #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)}
        logoutButton.layer.borderColor = UIColor.systemGray3.cgColor
        logoutButton.layer.borderWidth = 2.3
        logoutButton.layer.cornerRadius = 10
        
        keepButton.layer.cornerRadius = 10
        keepButton.backgroundColor = UIColor{_ in return #colorLiteral(red: 0.4016079903, green: 0.7575066686, blue: 0.7143911123, alpha: 1)}
        keepButton.tintColor = UIColor.white
        
        cancelButton.layer.cornerRadius = 10
        cancelButton.backgroundColor = UIColor{_ in return #colorLiteral(red: 0.4016079903, green: 0.7575066686, blue: 0.7143911123, alpha: 1)}
        cancelButton.tintColor = UIColor{_ in return #colorLiteral(red: 0.9618290067, green: 0.9513654113, blue: 0.9495180249, alpha: 1)}
        
        profileImageChangeButton.layer.cornerRadius = 10
        profileImageChangeButton.backgroundColor = UIColor{_ in return #colorLiteral(red: 0.4016079903, green: 0.7575066686, blue: 0.7143911123, alpha: 1)}
        profileImageChangeButton.tintColor = UIColor.white
        
        
      //  keepButton.tintColor = UIColor{_ in return #colorLiteral(red: 1, green: 0.6676921248, blue: 0.004999437369, alpha: 1)}
        //NCMBFileからUserIdが結合しているimageFileをゲットする
        let file = NCMBFile.file(withName: (NCMBUser.current()?.objectId)!, data: nil) as! NCMBFile
        file.getDataInBackground{ (data, error) in
            if error != nil{
                print(error.debugDescription)
                return
            }
            if let image = UIImage(data: data!) {
                self.userImageView.image = image
            }
        }

    }
    
    override func viewWillDisappear(_ animated: Bool) {
        if #available(iOS 13.0, *) {
            presentingViewController?.beginAppearanceTransition(true, animated: animated)
        }
    }
    
    func loadData(){
        if let user = NCMBUser.current(){
            userNameTextField.text = user.object(forKey: "userName") as? String
            introductionTextView.text = user.object(forKey: "introduction") as? String
            
        }else{
            let storyboard = UIStoryboard(name: "SignIn", bundle: .main)
            let rootVC = storyboard.instantiateViewController(identifier: "RootSigninVC")
            
            rootVC.modalPresentationStyle = .fullScreen
            self.present(rootVC, animated: true, completion: nil)
            
            let ud = UserDefaults.standard
            ud.set(false, forKey: "isLogin")
            ud.synchronize()
        }
            
    }
    
    
    @IBAction func keepButtonAction(_ sender: Any){
        if let user = NCMBUser.current() {
            user.setObject(userNameTextField.text, forKey: "userName")
            user.setObject(introductionTextView.text, forKey: "introduction")
            user.saveInBackground({ (error) in
                if error != nil{
                    print(error.debugDescription)
                    return
                }
                self.navigationController?.popViewController(animated: true)
                self.dismiss(animated: true, completion: nil)
            })
        }else{
            let storyboard = UIStoryboard(name: "SignIn", bundle: .main)
            let rootVC = storyboard.instantiateViewController(identifier: "RootSigninVC")
            
            
            rootVC.modalPresentationStyle = .fullScreen
            self.present(rootVC, animated: true, completion: nil)
            
            let ud = UserDefaults.standard
            ud.set(false, forKey: "isLogin")
            ud.synchronize()
        }
        
    }
    
    @IBAction func selectUserImage(_ sender: Any) {
        let actionController = UIAlertController(title: "画像の選択", message: "選択してください", preferredStyle: .actionSheet)
        let cameraAction = UIAlertAction(title: "カメラ", style: .default) { (action) in
            
            //カメラ起動
            let picker = UIImagePickerController()
            picker.sourceType = .camera
            picker.delegate = self
            picker.allowsEditing = true
            self.present(picker, animated: true, completion: nil)
        }
        let albumAction = UIAlertAction(title: "アルバム", style: .default) {(action) in
            
            //アルバム起動
            let picker = UIImagePickerController()
            picker.sourceType = .photoLibrary
            picker.delegate = self
            picker.allowsEditing = true
            self.present(picker, animated: true, completion: nil)
        }
        let cancelAction = UIAlertAction(title: "キャンセル", style: .cancel) { (action) in
            self.dismiss(animated: true, completion: nil)
        }
        actionController.addAction(cameraAction)
        actionController.addAction(albumAction)
        actionController.addAction(cancelAction)
        self.present(actionController, animated: true, completion: nil)
        
        
    }
    //画像が選択された後の処理
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        //選択された写真のデータをpickerImageに入れる
        if let pickerImage = info[.editedImage] as? UIImage {
            userImageView.image = pickerImage
            picker.dismiss(animated: true, completion: nil)
            
            //画像アップロード（NCMBFile）
            //画像をデータ型に変換
            let imageData = pickerImage.jpegData(compressionQuality: 0.1)
            //保存したいデータを含んだファイルを保存する
            //ファイルパスがデフォルトではただの文字列で抽出しにくい⇨userIdと結合する
            //会員管理のobjectIdが末尾についている
            let file = NCMBFile.file(withName: NCMBUser.current()?.objectId, data: imageData) as! NCMBFile
            //保存実行
            file.saveInBackground{ (error) in
                
                if error != nil{
                    print(error.debugDescription)
                    return
                }else{
                    //保存に成功したら画像を反映する
                    self.userImageView.image = pickerImage
                }
            } progressBlock: { (progress) in
                print(progress)
            }
        }
    }
    
    // 撮影orアルバムのキャンセル処理
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {

        picker.dismiss(animated: true, completion: nil)

    }
    // キーボードの設定
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        textView.resignFirstResponder()
        return true
    }


        
    
    
    @IBAction func CancelButtonAction(_ semder: Any) {
        self.dismiss(animated: true, completion: nil)
        }
    
    @IBAction func LogoutButtonAction(_ sender: Any) {
        let message = "本当にログアウトしますか？"
        let alert = UIAlertController(title: "ログアウト", message: message, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "キャンセル", style: .cancel){ (action) in
            alert.dismiss(animated: true, completion: nil)
            
        }
        let okAction = UIAlertAction(title: "OK", style: .default){ (action) in
            NCMBUser.logOut()
            
                let storyboard = UIStoryboard(name: "SignIn", bundle: .main)
                let rootVC = storyboard.instantiateViewController(identifier: "RootNavigationController")
                //モーダルをフルスクリーン表示
                rootVC.modalPresentationStyle = .fullScreen
                //画面表示
                self.present(rootVC, animated: true, completion: nil)
            
                //ログアウト状態を端末に保持
                let ud = UserDefaults.standard
                ud.set(false, forKey: "isLogin")
           
        }
        alert.addAction(cancelAction)
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)

            
//
//            let storyboard = UIStoryboard(name: "SignIn", bundle: .main)
//            let rootVC = storyboard.instantiateViewController(identifier: "RootNavigationController")
//            //モーダルをフルスクリーン表示
//            rootVC.modalPresentationStyle = .fullScreen
//            //画面表示
//            self.present(rootVC, animated: true, completion: nil)
//
//            //ログアウト状態を端末に保持
//            let ud = UserDefaults.standard
//            ud.set(false, forKey: "isLogin")
//
        }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    

}


    
