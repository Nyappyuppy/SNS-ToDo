//
//  ViewController.swift
//  MyProduct
//
//  Created by 田村 優奈 on 2022/09/30.
//

import UIKit
import NCMB
import Kingfisher
import PKHUD
import simd
import CoreMIDI
import EXTView


class ViewController: UIViewController, UITableViewDataSource, UISearchBarDelegate, UITableViewDelegate, TimelineTableViewCellDelegate {
    
    
    
    var selectedPost: NCMBObject?
    var posts = [NCMBObject]()
    var comments = [NCMBObject]()
    var followings = [NCMBUser]()
    var searchBar: UISearchBar!
    var users = [NCMBUser]()
    var blockUserIdArray = [String]()
    var favoriteNumber: Int = 0
    var textArray:[String] = []
    var str1 : String!
    var searchText1 = [String]()
    var postId: String!
    //var find: String!
    var find: [String]!
    var selectedUser: NCMBUser?
    var tweet: Bool! = false
    var ud = UserDefaults.standard
    var comCount: String = ""
    var stringCount = [String]()
    
    
    
    
    @IBOutlet var timelineTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
       
        
        guard let currentUser = NCMBUser.current() else {
            //ログインに戻る
            //ログアウト登録成功
            let storyboard = UIStoryboard(name: "SignIn", bundle: Bundle.main)
            let RootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
            UIApplication.shared.keyWindow?.rootViewController = RootViewController
            //ログアウト状態の保持
            let ud = UserDefaults.standard
            ud.set(false, forKey: "isLogin")
            ud.synchronize()
            return
            
        }
        
        let number = ud.integer(forKey: "likeCount")
        let commentNumber = ud.integer(forKey: "commentCount")
        
        
        timelineTableView.dataSource = self
        timelineTableView.delegate = self
        timelineTableView.rowHeight = 400
        
        
        let nib = UINib(nibName: "TimelineTableViewCell", bundle: Bundle.main)
        timelineTableView.register(nib, forCellReuseIdentifier:"TimelineCell")
        timelineTableView.tableFooterView = UIView()
        
        
        setSearchBar()
        setRefreshControl()
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        
        //f      loadUsers(searchText: nil)
       // getBlockUser()
        loadFollowingUsers()
        
    }
    
    func setSearchBar() {
        // NavigationBarにSearchBarをセット
        if let navigationBarFrame = self.navigationController?.navigationBar.bounds {
            let searchBar: UISearchBar = UISearchBar(frame: navigationBarFrame)
            searchBar.delegate = self
            searchBar.placeholder = "検索"
            searchBar.autocapitalizationType = UITextAutocapitalizationType.none
            navigationItem.titleView = searchBar
            navigationItem.titleView?.frame = searchBar.frame
            self.searchBar = searchBar
        }
    }
    
    func searchBarShouldBeginEditing(_ searchBar: UISearchBar) -> Bool {
        searchBar.setShowsCancelButton(true, animated: true)
        return true
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        print("あ1")
        loadTimeline(searchText: nil)
        
        searchBar.showsCancelButton = false
        searchBar.resignFirstResponder()
        
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        if searchBar.text == nil{
            print("あ2")
            loadTimeline(searchText: nil)
                        
        }
//        var filterArray: [String] = []
//
//        for i in 0..<posts.count{
//            print(posts.count,"ggg")
//            let searchtext = posts[i].object(forKey:"text")
//
//            textArray.append(searchtext as! String)
//            print(textArray)
//        }
//        let searchText = [searchBar.text] as! [String]
//
////        else{
////            return
////        }
//        print(searchBar.text,"gggggg")
//
//        //
//        //        if let text = searchBar.text{
//        //            if text == ""{
//        //                print(text,"wwwwwww")
//        //            }else{
//        print(searchText,"wwwwwww")
//        filterArray = textArray.filter { (str) -> Bool in
//
//            print(str, "jjjjjjjjj")
//            str1 = str
//        searchText1 = [searchBar.text] as! [String]
        print("あ3")
        loadTimeline(searchText: searchBar.text)
//            return true
        }
        
    
        func loadSearch(searchTextž:String?){
            let query = NCMBQuery(className: "Declare")
            print(posts.count, "前")
            query?.whereKey("text", equalTo: ["実験マウス1"])
           
        print(searchText1, "tututututtutu")
            query?.findObjectsInBackground({(result, error) in
            if error != nil{
                print(error)
            }else{
                print("成功！")
                for postObject in result as! [NCMBObject]{
                    let user = postObject.object(forKey: "user") as! NCMBUser
                    print(user)
                    print(postObject)
                    if self.blockUserIdArray.firstIndex(of: user.objectId) == nil{
                        //postsっていう別の変数(箱)にデータを写変える文章
                        self.posts.append(postObject)
                        print(self.searchText1, "hhhhhhhhhh")
                    }
                    //                    if user.object(forKey: "active") as? Bool != false{
                    //                        self.posts.append(postObject)
                    //
                    //                    }
                }
                self.timelineTableView.reloadData()
                print(self.posts.count, "あと")
            }
            
        })
    }
    

    
    
    
    //    func loadUsers(searchText: String?) {
    //            let query = NCMBUser.query()
    //            // 自分を除外
    //            query?.whereKey("objectId", notEqualTo: NCMBUser.current().objectId)
    //            // 退会済みアカウントを除外
    //            query?.whereKey("active", notEqualTo: false)
    //            // 検索ワードがある場合
    //            if let text = searchText {
    //
    //                query?.whereKey("text", equalTo: text)
    //                self.performSegue(withIdentifier: "toSearchResult", sender: nil)
    ////                query?.whereKey("text",equalTo: text)
    //                }
    //
    //        query?.limit = 500
    //                query?.order(byDescending: "createDate")
    //                query?.findObjectsInBackground({ (result, error) in
    //                    if error != nil {
    //                        HUD.show(.labeledError(title: error!.localizedDescription, subtitle: nil))
    //                    } else {
    //                        // 取得した新着500件のユーザーを格納
    //                        self.users = result as! [NCMBUser]
    //
    //                    }
    //                })
    //
    //        }
    
    
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toComment" {
            let commentViewController = segue.destination as! CommentViewController
            print(selectedPost?.objectId)
            commentViewController.postId = selectedPost?.objectId as! String
            
            //ユーザー情報を渡す時に使う。
            
        }else if segue.identifier == "toSelectMe"{
            let profileViewController = segue.destination as! ProfileViewController
            print(selectedPost?.objectId)
            profileViewController.user = selectedPost?.object(forKey: "user") as? NCMBUser
            
            
        }else if segue.identifier == "toSelectedUser"{
            let selectedUserViewController = segue.destination as! SelectedUserViewController
            print(selectedPost?.objectId)
            selectedUserViewController.afterSelectedUser = selectedPost?.object(forKey: "user") as? NCMBUser
            
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let timelineCell = tableView.dequeueReusableCell(withIdentifier: "TimelineCell") as! TimelineTableViewCell
        
        timelineCell.delegate = self
        timelineCell.tag = indexPath.row
        
        let user = posts[indexPath.row].object(forKey: "user") as! NCMBUser
        
        if user.object(forKey: "userName") as! String != "" {
            timelineCell.userNameLabel.text = user.object(forKey: "userName") as! String
        }else{
            timelineCell.userNameLabel.text = "表示名なし"
        }
        
        
        let userObjectId = user.object(forKey: "objectId") as! String
        let appId = "BAv7MRjuGKuR33Jj"
        let userImageUrl = "https://mbaas.api.nifcloud.com/2013-09-01/applications/" + appId + "/publicFiles/" + userObjectId
        
        timelineCell.userImageView.kf.setImage(with: URL(string: userImageUrl), placeholder: UIImage(systemName: "person"), options: nil, progressBlock: nil)
        
        timelineCell.declareTextView.text = posts[indexPath.row].object(forKey: "text") as! String
        timelineCell.timeLimitLabel.layer.cornerRadius = 2
        timelineCell.favoriteButton.tintColor = UIColor{_ in return #colorLiteral(red: 1, green: 0.6676921248, blue: 0.004999437369, alpha: 1)}
        timelineCell.commentButton.tintColor = UIColor{_ in return #colorLiteral(red: 1, green: 0.6676921248, blue: 0.004999437369, alpha: 1)}
        
        if posts[indexPath.row].object(forKey: "tweet") as? String == "Declare" || posts[indexPath.row].object(forKey: "tweet") as? [String] == []{
            print("SEN")
            timelineCell.timeLimitLabel.text = posts[indexPath.row].object(forKey: "date") as? String
           // timelineCell.timeLimitLabel.backgroundColor = UIColor{_ in return #colorLiteral(red: 0.9815623164, green: 0.6431372549, blue: 0.568627451, alpha: 1)}
           
        }else{
            print("BOYA")
            timelineCell.timeLimitLabel.isHidden = true
        }
        let commentViewController = CommentViewController()
        let likeUsers = posts[indexPath.row].object(forKey: "likeUser") as? [String] ?? []
        if likeUsers.contains(NCMBUser.current()?.objectId as! String) == false {
                    timelineCell.favoriteButton.setImage(UIImage(systemName: "heart"),for: .normal)
                }else{
                    timelineCell.favoriteButton.setImage(UIImage(systemName: "heart.fill"),for: .normal)
                }
        timelineCell.favoriteCountLabel.text = "\(likeUsers.count)"
      
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            //ここに処理
            //timelineCell.commentCountLabel.text = self.stringCount[timelineCell.tag]+"件"
        }
        
      
//        var commmentArray = [NCMBObject]()
//        // 重複している要素の取得
//        var set = Set<[NCMBObject]>()
//        let duplicatedEArray = NSOrderedSet(array: commmentArray.filter { !set.insert([$0]).inserted} ).array as! [String]
//
//        //ユニークな要素の取得
//        let noDuplicatedArray = NSOrderedSet(array: commmentArray).array as! [String]
//        let uniqueEArray = noDuplicatedArray.filter{ v in return !duplicatedEArray.contains(v) }
//
//     //   let comCount = timelineCell.commentCountLabel.text
//
    
        let df = DateFormatter()
        df.dateFormat = "yyyy/MM/dd HH:mm"
        let date = posts[indexPath.row].createDate as! Date
        timelineCell.timestampLabel.text = df.string(from: date)
//
//        loadComments()
        return timelineCell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        selectedPost = posts[indexPath.row]
        
        // self.performSegue(withIdentifier: "toComment", sender: nil)
        // 選択状態の解除
        //tableView.deselectRow(at: indexPath, animated: true)
        let user = posts[indexPath.row].object(forKey: "user") as! NCMBUser
        print((selectedPost?.object(forKey: "user") as? NCMBUser)?.objectId,"誰")
        print(NCMBUser.current(),"誰2")
        if (selectedPost?.object(forKey: "user") as? NCMBUser)?.objectId == NCMBUser.current().objectId{
            print("why")
            performSegue(withIdentifier: "toSelectMe", sender: nil)
            tableView.deselectRow(at: indexPath, animated: true)
            
            
        }else{
            performSegue(withIdentifier: "toSelectedUser", sender: nil)
            tableView.deselectRow(at: indexPath, animated: true)
            
        }
    }
    
    func didTapFavoriteButton(targetcell tableViewCell: UITableViewCell, targetButton button: UIButton) {
        guard let currentUser = NCMBUser.current() else{
            let storyboard = UIStoryboard(name: "SignIn", bundle: Bundle.main)
            let rootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
            UIApplication.shared.windows.first{ $0.isKeyWindow }?.rootViewController = rootViewController
            
            let ud = UserDefaults.standard
            ud.set(true, forKey: "isLogin")
            ud.synchronize()
            return
            
        }
        let favoriteUsers = posts[tableViewCell.tag].object(forKey: "likeUser") as? [String]
        HUD.show(.progress, onView: self.view)
        
        if favoriteUsers?.contains((NCMBUser.current()?.objectId)!) == false || favoriteUsers == nil {
                   //ボタンを押す前にいいねしてなかったら
                   posts[tableViewCell.tag].addUniqueObject(currentUser.objectId, forKey: "likeUser")
                   posts[tableViewCell.tag].saveEventually { error in
                       HUD.hide(animated: true)
                       if error != nil{
                           print(error)
                       }else{
                           print("あ4")
                           HUD.hide(animated: true)
                           self.loadTimeline(searchText: nil)
                       }
                   }
               } else {
                   //ボタンを押す前にいいねしていたら
                  posts[tableViewCell.tag].removeObjects(in: [NCMBUser.current().objectId], forKey: "likeUser")
                  posts[tableViewCell.tag].saveEventually { (error) in
                       HUD.hide(animated: true)
                       if error != nil{
                           print(error)
                       }else{
                           print("あ5")
                         //  HUD.hide(animated: true)
                           self.loadTimeline(searchText: nil)
                       }
                   }
               }
           

        
        
//        let query = NCMBQuery(className: "Declare")
//        query?.whereKey("objectId", equalTo: "objectId")
//        
//        query?.getObjectInBackground(withId: posts[tableViewCell.tag].objectId, block: { (declare,error) in
//            declare?.addUniqueObject(currentUser.objectId, forKey: "likeUser")
//            declare?.saveEventually({ (error) in
//                HUD.hide(animated: true)
//                if error != nil{
//                    print(error)
//                } else {
//                    print("あ6")
//                    self.loadTimeline(searchText: nil)
//                }
//            })
//        })
        
    }
    
    func didTapCommentButton(targetcell tableViewCell: UITableViewCell, targetButton button: UIButton) {
        selectedPost = posts[tableViewCell.tag]
        self.performSegue(withIdentifier: "toComment", sender: nil)
        
        guard let currentUser = NCMBUser.current() else{
            let storyboard = UIStoryboard(name: "SignIn", bundle: Bundle.main)
            let rootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
            UIApplication.shared.windows.first{ $0.isKeyWindow }?.rootViewController = rootViewController
            
            let ud = UserDefaults.standard
            ud.set(true, forKey: "isLogin")
            ud.synchronize()
            return
            //
        }
        //
//        let commentUsers = posts[tableViewCell.tag].object(forKey: "commentUser") as? [String]
//        HUD.show(.progress, onView: self.view)
//        //
//        //
//        let query = NCMBQuery(className: "Declare")
//        query?.getObjectInBackground(withId: posts[tableViewCell.tag].objectId, block: { (declare,error) in
//
//            declare?.addUniqueObject(currentUser.objectId, forKey: "commentUser")
//            declare?.saveEventually({ (error) in
//                if error != nil{
//                    print(error)
//                } else {
//                    //成功した時に消す
//                    HUD.hide(animated: true)
//                    //                        self.loadTimeline()
//                    print("roiroiroi")
//                }
//            })
//        })
        
        
    }
    
    
    func didTapMenuButton(targetcell tableViewCell: UITableViewCell, targetButton button: UIButton) {
        
            let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
            let cancelAction = UIAlertAction(title: "キャンセル", style: .cancel){ (action) in
                alertController.dismiss(animated: true, completion: nil)
                
            }
        let selectedPostUser = posts[tableViewCell.tag].object(forKey: "user") as! NCMBUser
        if selectedPostUser.object(forKey: "objectId") as! String == NCMBUser.current()?.objectId{
            let deleteAction = UIAlertAction(title: "削除する", style: .destructive){ (action) in
                HUD.show(.progress, onView: self.view)
                let query = NCMBQuery(className: "Declare")
                query?.getObjectInBackground(withId: self.posts[tableViewCell.tag].objectId, block: {(post, error) in
                    if error != nil{
                        print(error)
                    }else{
                        // 取得した投稿オブジェクトを削除
                        post?.deleteInBackground({ (error) in
                            if error != nil{
                                print(error)
                            }else{
                                //再読み込み
                                print("あ7")
                                self.loadTimeline(searchText: nil)
                                //読み込み(HUD)を直ちに消去する
                                HUD.hide(animated: true)
                            }
                        })
                    }
                })
            }
            alertController.addAction(deleteAction)
            alertController.addAction(cancelAction)
            
            self.present(alertController, animated: true, completion: nil)
        }else{
           
            let reportAction = UIAlertAction(title: "報告する", style: .destructive){ (action) in
                let object = NCMBObject(className: "Report")
                object?.setObject(self.posts[tableViewCell.tag].objectId, forKey: "reportPostId")
                object?.setObject(NCMBUser.current().objectId, forKey: "userId")
                object?.saveInBackground({ (error) in
                    if error != nil{
                        //もし保存する際にエラーがあったらその地域の言葉でエラーの内容を表示させます。
                        HUD.flash(.labeledError(title: error?.localizedDescription, subtitle: nil), delay: 1)
                    }else{
                        HUD.flash(.labeledError(title: "この投稿を報告しました。", subtitle: "ご協力ありがとうございました。"), delay: 1)
                        
                    }
                })
            }
            //ブロック機能
            let blockAction = UIAlertAction(title: "ブロックする", style: .default) {(action) in
                HUD.show(.progress, onView: self.view)
                //NCMBのBlockクラスにオブジェクトを追加
                let object = NCMBObject(className: "Block")
                //"blockUserId"をキーとしてブロックされる側（投稿者）のオブジェクトIDを格納
                let user = self.posts[tableViewCell.tag].object(forKey: "user") as! NCMBUser
                object?.setObject(user.objectId, forKey: "blockUserId")
                //"user"をキーとしてブロックする側（現在ログインしているユーザー）をNCMBUser型として格納
                object?.setObject(NCMBUser.current(), forKey: "user")
                //NCMB上にオブジェクトを保存
                object?.saveInBackground({ (error) in
                    if error != nil{
                        HUD.show(.progress, onView: self.view)
                    }else{
                        HUD.hide(animated: true)
                        self.getBlockUser()
                    }
                })
                
            }
            alertController.addAction(reportAction)
            alertController.addAction(blockAction)
            alertController.addAction(cancelAction)
            
            self.present(alertController, animated: true, completion: nil)
        }
        
    }
    
    
    
    //ログインユーザーがブロックしているユーザーのオブジェクトIDを格納する関数
    func getBlockUser(){
        //NCMBのBlockクラスのクエリを宣言
        let query = NCMBQuery(className: "Block")
        //検索結果にuserカラムの情報を含める
        query?.includeKey("user")
        //userカラムがログインユーザーと一致するレコードを取得
        query?.whereKey("user", equalTo: NCMBUser.current())
        query?.findObjectsInBackground({ (result, error) in
            if error != nil{
                HUD.flash(.labeledError(title: error?.localizedDescription, subtitle: nil), delay: 1)
            }else{
                //removeAll()で初期化をし、データの重複を防ぐ
                self.blockUserIdArray.removeAll()
                for blockObject in result as! [NCMBObject]{
                    //blockUserIdArrayに取得したレコードのblockUserIdカラムの要素のみを加える
                    self.blockUserIdArray.append(blockObject.object(forKey: "blockUserId") as! String)
                }
                //タイムラインを読み込みする
                print("あ8")
                self.loadTimeline(searchText: nil)
            }
        })
    }
    
    
    
    func setRefreshControl() {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(reloadTimeline(refreshControl:)), for: .valueChanged)
        timelineTableView.addSubview(refreshControl)
    }
    @objc func reloadTimeline(refreshControl: UIRefreshControl){
        refreshControl.beginRefreshing()
        self.loadFollowingUsers()
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            refreshControl.endRefreshing()
        }
    }
    
//    func loadComments(){
//        comments = [NCMBObject]()
//        let commentQuery = NCMBQuery(className: "Comment")
//        commentQuery?.whereKey("postId", equalTo: "postId")
//        commentQuery?.findObjectsInBackground({(result, error) in
//            if error != nil{
//                print(error)
//            }else{
//                DispatchQueue.main.async {
//                    let timelineTableViewCell = TimelineTableViewCell()
//                    for cm in result as! [NCMBObject]{
//                        let commentPostId = cm.object(forKey: "postId") as! String
//                        self.comments.append(cm)
//                    }
//                    
//                }
//            }
//        })
//    }
//
//    //コメント読み込み
//    func loadComments(){
//       // comments = [NCMBObject]()
//       //
//        HUD.show(.progress, onView: self.view)
////
//        let query = NCMBQuery(className: "Comment")
//        query?.whereKey("postId", equalTo: postId)
//        query?.includeKey("user")
//        query?.findObjectsInBackground({ (result,error) in
//            if error != nil{
//                HUD.hide(animated: true)
//            }else{
//                HUD.hide(animated: true)
//
//                for commentObject in result as! [NCMBObject] {
//
//                    //コメントの文字を取得
//                    let text = commentObject.object(forKey: "text") as? String
//                    self.comments.append(commentObject)
////
//                }
////
//            }
//        })
//    }
//
    func loadFollowingUsers(){
        //フォロー中の人だけ持ってくる
        let query = NCMBQuery(className: "follow")
        query?.includeKey("followingUser")
        query?.whereKey("user", equalTo: NCMBUser.current())
        query?.whereKey("following", equalTo: "true")

        query?.findObjectsInBackground({ (result, error) in
            if error != nil {
                print(error)
            } else {
                //               ブロックのuserを読み込む関数を呼び込む
                       self.getBlockUser()
                       self.followings = [NCMBUser]()

                       for following in result as! [NCMBObject] {
                           self.followings.append(following.object(forKey: "followingUser") as! NCMBUser)
                       }
                       self.followings.append(NCMBUser.current())
                print("あ9")
                self.loadTimeline(searchText: self.searchBar.text)
                   }
               })
           }
        
    
    
    
    func loadTimeline(searchText: String?){
        
        guard let currentUser = NCMBUser.current() else{
            
            let storyboard = UIStoryboard(name: "SignIn", bundle: Bundle.main)
            let rootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
            UIApplication.shared.windows.first { $0.isKeyWindow }?.rootViewController = rootViewController
            
            let ud = UserDefaults.standard
            ud.set(true, forKey: "isLogin")
            return
        }
        
        
        
        posts = [NCMBObject]()
        comments = [NCMBObject]()
        stringCount = [String]()
        
        let query = NCMBQuery(className: "Declare")
        let query2 = NCMBQuery(className: "Comment")
        
        query?.order(byDescending: "createDate")
        query?.includeKey("user")
        query?.whereKey("user", containedIn: followings)
        query?.findObjectsInBackground({(result, error) in
            if error != nil{
                print(error)
            }else{
                print("成功！！！")
                for postObject in result as! [NCMBObject]{
                    
                    let user = postObject.object(forKey: "user") as! NCMBUser
                    let StringText = postObject.object(forKey: "text") as! String
                  //  let postId = postObject.object(forKey: "postId") as! String
                    let objectId = postObject.objectId as! String
                    query2?.whereKey("postId", equalTo: objectId)
                    query2?.countObjectsInBackground({(count,error) in
                        if error != nil{
                            print(error)
                        }else{
                            DispatchQueue.main.async {
                                self.comCount  = String(count)
                                
                                print(self.comCount,"kkkkkk")
                                self.stringCount.append(self.comCount)
                                print(self.stringCount.count,"lllll")
                            }
                        }
                    })
//                    query2?.findObjectsInBackground({(result2, error) in
//                        if error != nil{
//                            print(error)
//                        }else{
//                            for commentObject in result2 as! [NCMBObject]{
//                            let postId = commentObject.object(forKey: "postId") as! String
//                                if objectId == postId{
//                                    self.comCount += 1
//                             //       self.comments.append(commentObject)
//                                }else{
//                                    self.comCount += 0
//                                }
//                                self.comeCount = self.comCount
//
//                            }
////                            if self.comments.count != nil{
////                                self.comCount = self.comments.count
////                            }else{
////                                self.comCount = 0
////                            }
//
//                        }
//                    })
                    print(user)
                    print(postObject)
                    if self.blockUserIdArray.firstIndex(of: user.objectId) == nil{
                        if let text = searchText{
                            print("jonjonjon")
                            
                            if StringText.contains(text){
                                //postsっていう別の変数(箱)にデータを写変える文章
                                self.posts.append(postObject)
                            
                            }
                           
                        }else{
                            self.posts.append(postObject)
                        }
                       
                        
                    }
                    //                    if user.object(forKey: "active") as? Bool != false{
                    //                        self.posts.append(postObject)
                    //
                    //                    }
                }
                self.timelineTableView.reloadData()
            }
        })
        
    }
    
  
    
    

    

    
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
