//
//  ToDoDetailViewController.swift
//  MyProduct
//
//  Created by Nyappi on 2022/10/19.
//

import UIKit
import NCMB

class ToDoDetailViewController: UIViewController {

    
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var toDoDetailTextView: UITextView!
    
    var postId: String!
    var todoList = [String]()
    var posts = [NCMBObject]()
    var selectedTodo: NCMBObject!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        guard let currentUser = NCMBUser.current() else {
                   //ログインに戻る
                   //ログアウト登録成功
                   let storyboard = UIStoryboard(name: "SignIn", bundle: Bundle.main)
                   let RootViewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController")
                   UIApplication.shared.keyWindow?.rootViewController = RootViewController
                   //ログアウト状態の保持
                   let ud = UserDefaults.standard
                   ud.set(false, forKey: "isLogin")
                   ud.synchronize()
                   return
            
               }
        toDoDetailTextView.text = selectedTodo.object(forKey: "text") as! String
        timeLabel.text = selectedTodo.object(forKey: "date") as? String
        

      
        
        // Do any additional setup after loading the view.
    }
    
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
